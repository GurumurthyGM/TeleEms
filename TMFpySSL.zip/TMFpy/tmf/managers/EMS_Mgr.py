from tmf.tmfutility import *


class EMS:

    def getTopology(self, mngr, return_corba_obj=0):
        return self.getAllTopLevelTopologicalLinks(mngr, return_corba_obj=return_corba_obj)

    def getAllTopLevelTopologicalLinks(self, mngr, return_corba_obj=0):
        allobjs, iterator = mngr.getAllTopLevelTopologicalLinks(FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getEMS(self, mngr, return_corba_obj=0):
        ret = mngr.getEMS()
        if not return_corba_obj:
            return corbaObjToDict(ret)
        else:
            return ret

    def getAllMLRAs(self, mngr, return_corba_obj=0):
        allobjs, iterator = mngr.getAllMLRAs(FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllMLSNPPLinks(self, mngr, return_corba_obj=0):
        allobjs, iterator = mngr.getAllMLSNPPLinks(True, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllTopLevelSubnetworks(self, mngr, return_corba_obj=0):
        allobjs, iterator = mngr.getAllTopLevelSubnetworks(FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllTopLevelSubnetworkNames(self, mngr, return_corba_obj=0):
        allobjs, iterator = mngr.getAllTopLevelSubnetworkNames(FETCH_BULK)
        # print ">>>>>",allobjs
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllMLSNPPLinksWithTP(self, mngr, tpName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllMLSNPPLinksWithTP(tpName, True, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllMLSNPPLinksWithMLSNs(self, mngr, mLRANames=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllMLSNPPLinksWithMLSNs(mLRANames, True, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllMLSNPPs(self, mngr, return_corba_obj=0):
        allobjs, iterator = mngr.getAllMLSNPPs(True, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllMLSNPPsWithTP(self, mngr, tPName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllMLSNPPsWithTP(tPName, True, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllTopLevelTopologicalLinkNames(self, mngr, return_corba_obj=0):
        allobjs, iterator = mngr.getAllTopLevelTopologicalLinkNames(FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getTopLevelTopologicalLink(self, mngr, topoLinkName=[], return_corba_obj=0):
        allobjs = mngr.getTopLevelTopologicalLink(topoLinkName)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getAllEMSAndMEActiveAlarms(self, mngr, excludeProbCauseList=[], excludeSeverityList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllEMSAndMEActiveAlarms(excludeProbCauseList, excludeSeverityList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllEMSSystemActiveAlarms(self, mngr, excludeSeverityList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllEMSSystemActiveAlarms(excludeSeverityList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def deleteTopologicalLink(self, mngr, topoLinkName=[], return_corba_obj=0):
        allobjs, iterator = mngr.deleteTopologicalLink(topoLinkName)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllASAPs(self, mngr, return_corba_obj=0):
        allobjs, iterator = mngr.getAllASAPs(FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def acknowledgeAlarms(self, mngr, acknowledgeIDList=[], additionalInfo=[], return_corba_obj=0):
        allobjs = mngr.acknowledgeAlarms(acknowledgeIDList, additionalInfo)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def unacknowledgeAlarms(self, mngr, unacknowledgeIDList=[], additionalInfo=[], return_corba_obj=0):
        allobjs = mngr.unacknowledgeAlarms(unacknowledgeIDList, additionalInfo)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getAllEMSAndMEUnacknowledgedActiveAlarms(self, mngr, excludeProbCauseList=[], excludeSeverityList=[],
                                                 return_corba_obj=0):
        allobjs, iterator = mngr.getAllEMSAndMEUnacknowledgedActiveAlarms(excludeProbCauseList, excludeSeverityList,
                                                                          FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllEMSSystemUnacknowledgedActiveAlarms(self, mngr, excludeSeverityList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllEMSSystemUnacknowledgedActiveAlarms(excludeSeverityList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllASAPNames(self, mngr, return_corba_obj=0):
        allobjs, iterator = mngr.getAllASAPNames(FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getASAP(self, mngr, aSAPName=[], return_corba_obj=0):
        allobjs = mngr.getASAP(aSAPName)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getASAPbyResource(self, mngr, resourceName=[], layerRateList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getASAPbyResource(resourceName, layerRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getASAPAssociatedResourceNames(self, mngr, aSAPName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getASAPAssociatedResourceNames(aSAPName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllMLSNPPLinksWithTNAs(self, mngr, tNAList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllMLSNPPLinksWithTNAs(tNAList, True, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllMLSNPPsWithTNA(self, mngr, tNAList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllMLSNPPsWithTNAi(tNAList, True, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs
