from tmf.tmfutility import *

class EquipmentInventory:

	def getAllManagedElements(self, mngr, return_corba_obj=0):
		allobjs, iterator = mngr.getAllManagedElements(FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllManagedElementNames(self, mngr, return_corba_obj=0):
		allnames, iterator = mngr.getAllManagedElementNames(FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allnames.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allnames]
		else:
			return allnames

	def getContainedEquipment(self, mngr, eqholder, return_corba_obj=0):
		allobjs= mngr.getContainedEquipment(eqholder)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getEquipment(self, mngr, eqholder, return_corba_obj=0):
		allobjs= mngr.getEquipment(eqholder)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllEquipment(self, mngr, meName, return_corba_obj=0):
		allobjs, iterator = mngr.getAllEquipment(meName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllEquipmentNames(self, mngr, meName, return_corba_obj=0):
		allobjs, iterator = mngr.getAllEquipmentNames(meName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllSupportedPTPs(self, mngr, meName, return_corba_obj=0):
		allobjs, iterator = mngr.getAllSupportedPTPs(meName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllSupportedPTPNames(self, mngr, meName, return_corba_obj=0):
		allobjs, iterator = mngr.getAllSupportedPTPNames(meName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs
	
	def getAllSupportingEquipment(self, mngr, meName, return_corba_obj=0):
		allobjs= mngr.getAllSupportingEquipment(meName)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllSupportingEquipmentNames(self, mngr, meName, return_corba_obj=0):
		allobjs= mngr.getAllSupportingEquipmentNames(meName)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs
	def getSupportingEquipment(self, mngr, meName, return_corba_obj=0):
		allobjs= mngr.getSupportingEquipment(meName)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getSupportingEquipmentNames(self, mngr, meName, return_corba_obj=0):
		allobjs= mngr.getSupportingEquipmentNames(meName)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getSupportedEquipment(self, mngr, meName, return_corba_obj=0):
		allobjs= mngr.getSupportedEquipment(meName)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs


	def getSupportedEquipmentNames(self, mngr, meName, return_corba_obj=0):
		allobjs= mngr.getSupportedEquipmentNames(meName)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs


