from tmf.tmfutility import *

class TCProfile:
	
	def getAllTCProfiles(self, mngr, return_corba_obj=0):
		allobjs, iterator = mngr.getAllTCProfiles(FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobj

	def getTCProfile(self, mngr,tcProfileName=[], return_corba_obj=0):
		allobjs = mngr.getTCProfile(tcProfileName)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getTCProfileAssociatedTPs(self, mngr, tcProfileName=[],return_corba_obj=0):
		allobjs, iterator = mngr.getTCProfileAssociatedTPs(tcProfileName,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs
