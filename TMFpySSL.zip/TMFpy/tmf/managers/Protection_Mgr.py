from tmf.tmfutility import *

class Protection:


	def getAllProtectionGroups(self, mngr, meName = [], return_corba_obj = 0):
		allobjs, iterator = mngr.getAllProtectionGroups(meName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs


	def getAllEProtectionGroups(self, mngr, meName = [], return_corba_obj = 0):
		allobjs, iterator = mngr.getAllEProtectionGroups(meName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs


	def getProtectionGroup(self, mngr, pgName = [], return_corba_obj = 0):
		allobjs = mngr.getProtectionGroup(pgName)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs

	def getEProtectionGroup(self, mngr, ePGPname = [], return_corba_obj = 0):
		allobjs = mngr.getEProtectionGroup(ePGPname)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs

	def getAllNUTTPNames(self, mngr, pgName = [], return_corba_obj = 0):
		allobjs, iterator = mngr.getAllNUTTPNames(pgName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs


	def getAllPreemptibleTPNames(self, mngr, pgName = [], return_corba_obj = 0):
		allobjs, iterator = mngr.getAllPreemptibleTPNames(pgName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs




	def getAllProtectedTPNames(self, mngr, pgName = [], return_corba_obj = 0):
		allobjs, iterator = mngr.getAllProtectedTPNames(pgName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs		



	def retrieveSwitchData(self, mngr, reliableSinkCtpOrGroupName = [], return_corba_obj = 0):
		allobjs = mngr.retrieveSwitchData(reliableSinkCtpOrGroupName)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs	



	def retrieveESwitchData(self, mngr, ePGPname = [], return_corba_obj = 0):
		allobjs = mngr.retrieveESwitchData(ePGPname)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs		




	def performProtectionCommand(self, mngr, protectionCommand = [], reliableSinkCtpOrGroupName = [], fromTp = [], toTp = [], return_corba_obj = 0):
		allobjs = mngr.performProtectionCommand(protectionCommand, reliableSinkCtpOrGroupName, fromTp, toTp)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs	




	def getContainingPGNames(self, mngr, pTPName = [], return_corba_obj = 0):
		allobjs = mngr.getContainingPGNames(pTPName)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs	
