from tmf.tmfutility import *


class MultiLayerSubnetwork:

    def getAllManagedElements(self, mngr, subnetName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllManagedElements(subnetName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllManagedElementNames(self, mngr, subnetName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllManagedElementNames(subnetName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getMultiLayerSubnetwork(self, mngr, subnetName=[], return_corba_obj=0):
        allobjs = mngr.getMultiLayerSubnetwork(subnetName)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getAllTopologicalLinks(self, mngr, subnetName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllTopologicalLinks(subnetName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllTopologicalLinkNames(self, mngr, subnetName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllTopologicalLinkNames(subnetName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getTopologicalLink(self, mngr, topoLinkName=[], return_corba_obj=0):
        allobjs = mngr.getTopologicalLink(topoLinkName)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getAllEdgePoints(self, mngr, subnetName=[], tpLayerRateList=[], connectionLayerRateList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllEdgePoints(subnetName, tpLayerRateList, connectionLayerRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllEdgePointNames(self, mngr, subnetName=[], layerRateList=[], connectionLayerRateList=[],
                             return_corba_obj=0):
        allobjs, iterator = mngr.getAllEdgePointNames(subnetName, layerRateList, connectionLayerRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAssociatedTP(self, mngr, tpName=[], return_corba_obj=0):
        allobjs = mngr.getAssociatedTP(tpName)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getTPGroupingRelationships(self, mngr, tpName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getTPGroupingRelationships(tpName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllSubnetworkConnections(self, mngr, subnetName=[], connectionRateList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllSubnetworkConnections(subnetName, connectionRateList, 10)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(10)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllSubnetworkConnectionNames(self, mngr, subnetName=[], connectionRateList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllSubnetworkConnectionNames(subnetName, connectionRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllSubnetworkConnectionsWithTP(self, mngr, tpName=[], connectionRateList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllSubnetworkConnectionsWithTP(tpName, connectionRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllSubnetworkConnectionNamesWithTP(self, mngr, tpName=[], connectionRateList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllSubnetworkConnectionNamesWithTP(tpName, connectionRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getRoute(self, mngr, sncName=[], return_corba_obj=0):
        allobjs = mngr.getRoute(sncName, False)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getRouteAndTopologicalLinks(self, mngr, sncName=[], return_corba_obj=0):
        allobjs = mngr.getRouteAndTopologicalLinks(sncName)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getSNC(self, mngr, sncName=[], return_corba_obj=0):
        allobjs = mngr.getSNC(sncName)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getSNCsByUserLabel(self, mngr, userLabel='', return_corba_obj=0):
        allobjs = mngr.getSNCsByUserLabel(userLabel)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def createSNC(self, mngr, createData=[], tolerableImpact=[], emsFreedomLevel=[], return_corba_obj=0):
        allobjs, errorReason = mngr.createSNC(createData, tolerableImpact, emsFreedomLevel)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def activateSNC(self, mngr, sncName=[], tolerableImpact=[], emsFreedomLevel=[], tpsToModify=[], return_corba_obj=0):
        tpsToModify, allobjs, errorReason = mngr.createSNC(sncName, tolerableImpact, emsFreedomLevel, tpsToModify)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def createAndActivateSNC(self, mngr, createData=[], tolerableImpact=[], emsFreedomLevel=[], tpsToModify=[],
                             return_corba_obj=0):
        tpsToModify, allobjs, errorReason = mngr.createAndActivateSNC(createData, tolerableImpact, emsFreedomLevel,
                                                                      tpsToModify)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def deactivateSNC(self, mngr, sncName=[], tolerableImpact=[], emsFreedomLevel=[], tpsToModify=[],
                      return_corba_obj=0):
        tpsToModify, allobjs, errorReason = mngr.deactivateSNC(sncName, tolerableImpact, emsFreedomLevel, tpsToModify)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    '''

	def deleteSNC(self, mngr, sncName = [], emsFreedomLevel = [], return_corba_obj = 0):
		if(mngr.deactivateSNC(sncName, tolerableImpact, emsFreedomLevel, tpsToModify)):
			return 1

		else:
			return 0
	'''

    def deactivateAndDeleteSNC(self, mngr, sncName=[], tolerableImpact=[], emsFreedomLevel=[], tpsToModify=[],
                               return_corba_obj=0):
        tpsToModify, allobjs, errorReason = mngr.deactivateAndDeleteSNC(sncName, tolerableImpact, emsFreedomLevel,
                                                                        tpsToModify)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def checkValidSNC(self, mngr, createData=[], tpsToModify=[], return_corba_obj=0):
        allobjs = mngr.checkValidSNC(createData, tpsToModify, True)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getAllTPPools(self, mngr, subnetworkName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllTPPools(subnetworkName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllTPPoolNames(self, mngr, subnetworkName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllTPPoolNames(subnetworkName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllFixedSubnetworkConnections(self, mngr, subnetName=[], connectionRateList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllFixedSubnetworkConnections(subnetName, connectionRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllFixedSubnetworkConnectionNames(self, mngr, subnetName=[], connectionRateList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllFixedSubnetworkConnectionNames(subnetName, connectionRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllFixedSubnetworkConnectionsWithTP(self, mngr, tpName=[], connectionRateList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllFixedSubnetworkConnectionsWithTP(tpName, connectionRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllFixedSubnetworkConnectionNamesWithTP(self, mngr, tpName=[], connectionRateList=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllFixedSubnetworkConnectionNamesWithTP(tpName, connectionRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def createModifiedSNCinfo(self, mngr, sncName=[], routeId='', SNCModifyData=[], tolerableImpact=[],
                              tolerableImpactEffort=[], emsFreedomLevel=[], tpsToModify=[], return_corba_obj=0):
        tpsToModify, allobjs, errorReason = mngr.createModifiedSNC(sncName, routeId, SNCModifyData, tolerableImpact,
                                                                   tolerableImpactEffort, emsFreedomLevel, tpsToModify)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def swapSNC(self, mngr, nameOfSNCtoBeDeactivated=[], nameOfSNCtoBeActivated=[], emsFreedomLevel=[],
                tolerableImpact=[], tpsToModify=[], return_corba_obj=0):
        tpsToModify, allobjs, errorReason = mngr.createModifiedSNC(nameOfSNCtoBeDeactivated, nameOfSNCtoBeActivated,
                                                                   emsFreedomLevel, tolerableImpact, tpsToModify)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def modifySNC(self, mngr, sncName=[], routeId='', SNCModifyData=[], tolerableImpact=[], tolerableImpactEffort=[],
                  emsFreedomLevel=[], tpsToModify=[], return_corba_obj=0):
        tpsToModify, allobjs, errorReason = mngr.modifySNC(sncName, routeId, SNCModifyData, tolerableImpact,
                                                           tolerableImpactEffort, emsFreedomLevel, tpsToModify)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getBackupRoutes(self, mngr, sncName=[], routeId='', includeHigherOrderCCs=True, additionalInfo=[],
                        return_corba_obj=0):
        additionalInfo, allobjs = mngr.getBackupRoutes(sncName, routeId, includeHigherOrderCCs, additionalInfo)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs), corbaObjToDict(additionalInfo)
        else:
            return allobjs

    def switchRoute(self, mngr, sncName=[], routeId='', tolerableImpact=[], emsFreedomLevel=[], tpsToModify=[],
                    additionalInfo=[], return_corba_obj=0):
        additionalInfo, allobjs, errorReason = mngr.switchRoute(sncName, routeId, tolerableImpact, emsFreedomLevel,
                                                                tpsToModify, additionalInfo)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs), corbaObjToDict(additionalInfo)
        else:
            return allobjs, additionalInfo

    def addRoute(self, mngr, sncName=[], createRoute=[], tolerableImpact=[], emsFreedomLevel=[], return_corba_obj=0):
        allobjs, errorReason = mngr.addRoute(sncName, createRoute, tolerableImpact, emsFreedomLevel)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def removeRoute(self, mngr, sncName=[], routeId='', emsFreedomLevel=[], additionalInfo=[], return_corba_obj=0):
        allobjs = mngr.removeRoute(sncName, routeId, emsFreedomLevel, additionalInfo)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def setIntendedRoute(self, mngr, sncName=[], routeId='', additionalInfo=[], return_corba_obj=0):
        routeNameAndAdminStateList, allobjs = mngr.setIntendedRoute(sncName, routeId, additionalInfo)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs), corbaObjToDict(routeNameAndAdminStateList)
        else:
            return allobjs, routeNameAndAdminStateList

    def setRoutesAdminState(self, mngr, sncName=[], routeNameAndAdminStateList=[], return_corba_obj=0):
        additionalInfo, allobjs = mngr.setRoutesAdminState(sncName, routeNameAndAdminStateList)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs), corbaObjToDict(additionalInfo)
        else:
            return allobjs, additionalInfo

    def getIntendedRoute(self, mngr, sncName=[], includeHigherOrderCCs=True, additionalInfo=[], return_corba_obj=0):
        additionalInfo, allobjs = mngr.getIntendedRoute(sncName, includeHigherOrderCCs, additionalInfo)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs), corbaObjToDict(additionalInfo)
        else:
            return allobjs, additionalInfo

    def createTPPool(self, managers, newTPPoolCreateData=[], return_corba_obj=0):
        if 'MultiLayerSubnetwork' not in managers:
            print(4, "No manager - MultiLayerSubnetwork")
            return []
        manager = managers['MultiLayerSubnetwork']
        allobjs = manager.createTPPool(newTPPoolCreateData)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def deleteTPPool(self, manmngragers, tpPoolName=[], return_corba_obj=0):
        if (manmngragers.deleteTPPool(tpPoolName)):
            return 1
        else:
            return 0

    def modifyTPPool(self, mngr, tPPoolName=[], containedMembers=[], actionType='', return_corba_obj=0):
        allobjs = mngr.modifyTPPool(tPPoolName, containedMembers, actionType)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getTPPool(self, mngr, tPPoolName=[], return_corba_obj=0):
        allobjs, numberOfMembers, numberOfIdleMembers, descriptionOfUse = mngr.getTPPool(tPPoolName)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs), corbaObjToDict(numberOfMembers), corbaObjToDict(
                numberOfIdleMembers), corbaObjToDict(descriptionOfUse)
        else:
            return allobjs, numberOfMembers, numberOfIdleMembers, descriptionOfUse

    def getAllSubordinateMLSNs(self, mngr, subnetName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllSubordinateMLSNs(subnetName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllSubordinateRAidsWithConnection(self, mngr, subnetName=[], connection=[], routeType=[],
                                             return_corba_obj=0):
        allobjs = mngr.getAllSubordinateRAidsWithConnection(subnetName, connection, routeType)
        if not return_corba_obj:
            # print allobjs[0]
            # return corbaObjToDict(allobjs[0])
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getMLSNPPLink(self, mngr, mLSNPPLinkName=[], sNPListRequested=True, return_corba_obj=0):
        allobjs = mngr.getMLSNPPLink(mLSNPPLinkName, sNPListRequested)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getAllMLSNPPLinks(self, mngr, subnetName=[], sNPListRequested=True, return_corba_obj=0):
        allobjs, iterator = mngr.getAllMLSNPPLinks(subnetName, sNPListRequested, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllInternalMLSNPPLinks(self, mngr, subnetName=[], sNPListRequested=True, return_corba_obj=0):
        allobjs, iterator = mngr.getAllInternalMLSNPPLinks(subnetName, sNPListRequested, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllEdgeMLSNPPLinks(self, mngr, subnetName=[], sNPListRequested=True, return_corba_obj=0):
        allobjs, iterator = mngr.getAllEdgeMLSNPPLinks(subnetName, sNPListRequested, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllMLSNPPs(self, mngr, subnetName=[], sNPListRequested=True, return_corba_obj=0):
        allobjs, iterator = mngr.getAllMLSNPPs(subnetName, sNPListRequested, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllCallsAndTopLevelConnections(self, mngr, subnetName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllCallsAndTopLevelConnections(subnetName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllCallsAndTopLevelConnectionsAndSNCs(self, mngr, subnetName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllCallsAndTopLevelConnectionsAndSNCs(subnetName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllCallsAndTopLevelConnectionsWithME(self, mngr, subnetName=[], meName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllCallsAndTopLevelConnectionsWithME(subnetName, meName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllCallsAndTopLevelConnectionsAndSNCsWithME(self, mngr, subnetName=[], meName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllCallsAndTopLevelConnectionsAndSNCsWithME(subnetName, meName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllCallsAndTopLevelConnectionsAndSNCsWithTP(self, mngr, subnetName=[], tPName=[], return_corba_obj=0):
        allobjs, iterator = mngr.getAllCallsAndTopLevelConnectionsAndSNCsWithTP(subnetName, tPName, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllCallIdsWithTP(self, mngr, sNPPOrTNAName=[], return_corba_obj=0):
        allobjs = mngr.getAllCallIdsWithTP(sNPPOrTNAName)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getAllCallIdsWithSNPPOrTNAName(self, mngr, sNPPOrTNAName=[], return_corba_obj=0):
        allobjs = mngr.getAllCallIdsWithSNPPOrTNAName(sNPPOrTNAName)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getCallAndTopLevelConnectionsAndSNCs(self, mngr, callName=[], return_corba_obj=0):
        allobjs = mngr.getCallAndTopLevelConnectionsAndSNCs(callName)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def getCallAndTopLevelConnections(self, mngr, callName=[], callId='', return_corba_obj=0):
        allobjs = mngr.getCallAndTopLevelConnections(callName, callId)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def establishCall(self, mngr, callCreateData=[], connectionCreateDataList=[], routeGroupsNumber='', tpsToModify=[],
                      return_corba_obj=0):
        tpsToModify, allobjs, sNCsNotCreated, partialSNCs, errorReason = mngr.establishCall(callCreateData.value(),
                                                                                            connectionCreateDataList.value(),
                                                                                            routeGroupsNumber.value(),
                                                                                            tpsToModify.value())
        if not return_corba_obj:
            return corbaObjToDict(allobjs), corbaObjToDict(tpsToModify), corbaObjToDict(sNCsNotCreated), corbaObjToDict(
                partialSNCs)
        else:
            return tpsToModify, allobjs, sNCsNotCreated, partialSNCs, errorReason

    def modifyCall(self, mngr, callName=[], callModifyData=[], return_corba_obj=0):
        allobjs = mngr.modifyCall(callName.value(), callModifyData.value())
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def releaseCall(self, mngr, callName=[], tpsToModify=[], return_corba_obj=0):
        tpsToModify, allobjs, errorReason = mngr.releaseCall(callName.value(), tpsToModify.value())
        if not return_corba_obj:
            return corbaObjToDict(allobjs), corbaObjToDict(tpsToModify)
        else:
            return tpsToModify, allobjs, errorReason

    def getCall(self, mngr, callName=[], return_corba_obj=0):
        allobjs = mngr.getCall(callName)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def addConnections(self, mngr, callName=[], connectionsToAdd=[], connectionRouteReArrangementAllowed=True,
                       tpsToModify=[], return_corba_obj=0):
        tpsToModify, allobjs, partialSNCs, errorReason = mngr.addConnections(callName.value(), connectionsToAdd.value(),
                                                                             connectionRouteReArrangementAllowed.value(),
                                                                             tpsToModify.value())
        if not return_corba_obj:
            return corbaObjToDict(allobjs), corbaObjToDict(tpsToModify), corbaObjToDict(partialSNCs)
        else:
            return tpsToModify, allobjs, partialSNCs, errorReason

    def removeConnections(self, mngr, NamcallName=[], connectionNamesList=[], tpsToModify=[], return_corba_obj=0):
        tpsToModify, allobjs, errorReason = mngr.removeConnections(NamcallName.value(), connectionNamesList.value(),
                                                                   tpsToModify.value())
        if not return_corba_obj:
            return corbaObjToDict(allobjs), corbaObjToDict(tpsToModify)
        else:
            return tpsToModify, allobjs, errorReason

    def getConnectionsAndRouteDetails(self, mngr, callID='', mLRAName=[], sNPOrSNPPID='', routeType=[],
                                      mLSNPPLinkRequested=True, return_corba_obj=0):
        allobjs = mngr.getConnectionsAndRouteDetails(callID, mLRAName, sNPOrSNPPID, mLSNPPLinkRequested, routeType)
        if not return_corba_obj:
            return corbaObjToDict(allobjs)
        else:
            return allobjs

    def modifyDiversityAndCorouting(self, mngr, callName=[], callDiversity=[], routeGroupInfoList=[],
                                    connectionRouteReArrangementAllowed=True, routeGroupsNumber='', additionalInfo=[],
                                    return_corba_obj=0):
        additionalInfo, allobjs = mngr.modifyDiversityAndCorouting(callName.value(), callDiversity.value(),
                                                                   routeGroupInfoList.value(),
                                                                   connectionRouteReArrangementAllowed.value(),
                                                                   routeGroupsNumber.value(), additionalInfo.value())
        if not return_corba_obj:
            return corbaObjToDict(allobjs), corbaObjToDict(additionalInfo)
        else:
            return allobjs

    def setUserLabel(self, mngr, subnetName, newname):
        mngr.setUserLabel(subnetName, newname, False)
