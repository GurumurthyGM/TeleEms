from tmf.tmfutility import *

class PerformanceManagement:
	
	def getMEPMcapabilities(self, mngrs, meName, tpLayerRateList=[], return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs = mngr.getMEPMcapabilities(meName, tpLayerRateList)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def disablePMData(self, mngrs,pmTPSelectList=[], return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs = mngr.disablePMData(pmTPSelectList)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def enablePMData(self, mngrs,pmTPSelectList=[], return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs = mngr.enablePMData(pmTPSelectList)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def clearPMData(self, mngrs,pmTPSelectList=[], return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs = mngr.clearPMData(pmTPSelectList)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getHoldingTime(self, mngrs):
		mngr = mngrs['PerformanceManagement']
		allobjs = mngr.getHoldingTime()
		return allobjs

	def getTCATPParameter(self, mngrs,tpName=[],tpLayerRateList=[], granularity=[],return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs = mngr.getTCATPParameter(tpName,tpLayerRateList, granularity)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllCurrentPMData (self, mngrs, pmTPSelectList=[], pmParameters=[], return_corba_obj = 0):
		mngr = mngrs['PerformanceManagement']
		allobjs, iterator = mngr.getAllCurrentPMData(pmTPSelectList, pmParameters,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getTCATPParameter(self, mngrs,tpName=[],tpLayerRateList=[], granularity=[],return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs = mngr.getTCATPParameter(tpName,tpLayerRateList, granularity)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def enableTCA(self, mngrs,pmTPSelectList=[], return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs = mngr.enableTCA(pmTPSelectList)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def disableTCA(self, mngrs,pmTPSelectList=[], return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs = mngr.disableTCA(pmTPSelectList)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getProfileAssociatedTPs(self, mngrs, profileName=[],return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs, iterator = mngr.getProfileAssociatedTPs(profileName,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					brek
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getTCAParameterProfile(self, mngrs,tcaParameterProfileName=[], return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs = mngr.getTCAParameterProfile(tcaParameterProfileName)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllTCAParameterProfileNames(self, mngrs, meName,return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs, iterator = mngr.getAllTCAParameterProfileNames(meName,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs



	def getAllPMPs(self, mngrs, meName,return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs, iterator = mngr.getAllPMPs(meName,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobj

	def getAllPMPNames(self, mngrs, meName,return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs, iterator = mngr.getAllPMPNames(meName,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobj

	def getAllTCAParameterProfiles(self, mngrs, meName,return_corba_obj=0):
		mngr = mngrs['PerformanceManagement']
		allobjs, iterator = mngr.getAllTCAParameterProfiles(meName,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobj

	def getHistoryPMData(self, mangers,destination=[], userName='', password='', pmTPSelectList=[], pmParameters=[], startTime=[], endTime=[], forceUpload=True):
		mngr = mngrs['PerformanceManagement']
		mngr.getHistoryPMData(destination,userName,password,pmTPSelectList,pmParameters, startTime, endTime, forceUpload)














