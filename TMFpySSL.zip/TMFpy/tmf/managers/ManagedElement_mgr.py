from tmf.idlc_tmf_v35 import globaldefs
from tmf.tmfutility import *

class ManagedElement:

	allNesNames = []
	def getAllManagedElements(self, mngr, return_corba_obj=0):
		allobjs, iterator = mngr.getAllManagedElements(FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			# print allobjs[0]
			# return corbaObjToDict(allobjs[0])
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllManagedElementNames(self, mngr, return_corba_obj=0):
		allnames, iterator = mngr.getAllManagedElementNames(FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allnames.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			# print allobjs[0]
			# return corbaObjToDict(allobjs[0])
			return [corbaObjToDict(obj) for obj in allnames]
		else:
			self.allNesNames = allnames
			return allnames

	def getContainingSubnetworkNames(self, mngr, allNesNames=[], return_corba_obj=0):	
		SubnetworkNames=[]
		SubnetworkNames = mngr.getContainingSubnetworkNames(allNesNames)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in SubnetworkNames]
		else:
			return SubnetworkNames

	def getAllPTPs(self, mngr, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllPTPs(meName, tpLayerRateList, connectiontpLayerRateList ,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllPTPsWithoutFTPs(self, mngr, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllPTPsWithoutFTPs(meName, tpLayerRateList, connectiontpLayerRateList ,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllFTPs(self, mngr, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllFTPs(meName, tpLayerRateList, connectiontpLayerRateList ,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllPTPNames(self, mngr, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllPTPNames(meName, tpLayerRateList, connectiontpLayerRateList ,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllPTPNamesWithoutFTPs(self, mngr, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllPTPNamesWithoutFTPs(meName, tpLayerRateList, connectiontpLayerRateList ,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllFTPNames(self, mngr, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllFTPNames(meName, tpLayerRateList, connectiontpLayerRateList ,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getTP(self,mngr,tpName,return_corba_obj=0):
		allobjs= mngr.getTP(tpName)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getManagedElement(self,mngr,meName,return_corba_obj=0):
		allobjs= mngr.getManagedElement(meName)	
		if return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return corbaObjToDict(allobjs)

	def getContainedPotentialTPs(self, mngr, tpName, tpLayerRateList=[], return_corba_obj=0):
		allobjs, iterator = mngr.getContainedPotentialTPs(tpName, tpLayerRateList, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs


	def getContainedPotentialTPNames(self, mngr, tpName, tpLayerRateList=[], return_corba_obj=0):
		allobjs, iterator = mngr.getContainedPotentialTPNames(tpName, tpLayerRateList, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getContainedInUseTPs(self, mngr, tpName, tpLayerRateList=[], return_corba_obj=0):
		allobjs, iterator = mngr.getContainedInUseTPs(tpName, tpLayerRateList, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getContainedInUseTPNames(self, mngr, tpName, tpLayerRateList=[], return_corba_obj=0):
		allobjs, iterator = mngr.getContainedInUseTPNames(tpName, tpLayerRateList, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getContainedCurrentTPs(self, mngr, tpName, tpLayerRateList=[], return_corba_obj=0):
		allobjs, iterator = mngr.getContainedCurrentTPs(tpName, tpLayerRateList, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getContainedCurrentTPNames(self, mngr, tpName, tpLayerRateList=[], return_corba_obj=0):
		allobjs, iterator = mngr.getContainedCurrentTPNames(tpName, tpLayerRateList, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getContainingTPs(self,mngr,tpName,return_corba_obj=0):
		allobjs= mngr.getContainingTPs(tpName)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getContainingTPNames(self,mngr,tpName,return_corba_obj=0):
		allobjs= mngr.getContainingTPNames(tpName)
		
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def	getAllActiveAlarms(self, mngr, meName, excludeProbCauseList=[],excludeSeverityList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllActiveAlarms(meName, excludeProbCauseList, excludeSeverityList, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def	getAllUnacknowledgedActiveAlarms(self, mngr, meName, excludeProbCauseList=[],excludeSeverityList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllUnacknowledgedActiveAlarms(meName, excludeProbCauseList, excludeSeverityList, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllCrossConnections(self, mngr, meName, LayerRateList=[], return_corba_obj=0):
		allobjs = []
		try:
			# self.getCapabilities(manager)
			allobjs, iterator = mngr.getAllCrossConnections(meName, LayerRateList, FETCH_BULK)
			# print '\n\n allobjs -- ',len(allobjs), allobjs[0]
			if iterator:
				more = True
				while more:
					more, iterobjs = iterator.next_n(FETCH_BULK)
					allobjs.extend(iterobjs)
					if not more:
						break
		except Exception, msg:
			print_traceback()
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs
	

	def createGTP(self, mngr, userLabel,forceUniqueness=True,owner='',listOfTPs=[],initialCTPname=[],gtpEffort=[],additionalCreationInfo=[], return_corba_obj=0):
		allobjs= mngr.createGTP(userLabel,forceUniqueness,owner,listOfTPs,initialCTPname,FETCH_BULK,gtpEffort,additionalCreationInfo)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getGTP(self, mngr, gtpName=[],return_corba_obj=0):
		allobjs= mngr.getGTP(gtpName)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllGTPs(self, mngr, meName, tpLayerRateList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllGTPs(meName, tpLayerRateList,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		else:
			if not return_corba_obj:
				return [corbaObjToDict(obj) for obj in allobjs]
			else:
				return allobjs

	def getAllGTPNames(self, mngr, meName, tpLayerRateList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllGTPNames(meName, tpLayerRateList,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		else:
			if not return_corba_obj:
				return [corbaObjToDict(obj) for obj in allobjs]
			else:
				return allobjs

	def getContainingGTP(self, mngr, ctpName=[],return_corba_obj=0):
		allobjs= mngr.getContainingGTP(ctpName)
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def verifyTMDAssignment(self, mngr, tpName, direction=[]):
		tmdAssignmentState,transmissionParams,additionalTPInfo= mngr.verifyTMDAssignment(tpName, direction)
		return tmdAssignmentState,transmissionParams,additionalTPInfo

	def getAllFixedCrossConnections(self, mngr, meName, connectiontpLayerRateList=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllFixedCrossConnections(meName, connectiontpLayerRateList ,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
                                allobjs.extend(iterobjs)
                                if not more:
                                        break
                else:
                        if not return_corba_obj:
                                return [corbaObjToDict(obj) for obj in allobjs]
                        else:
                                return allobjs

	def getPotentialFixedCCs(self, mngr,inputTP):
		ContainingTP,potentialCCList= mngr.getPotentialFixedCCs(inputTP)
		return ContainingTP,potentialCCList


	def getCTPsforPTP(self, mngr, ptp_name, all_ctps = 1, return_corba_obj=0):
		if all_ctps:
			allobjs, iterator = mngr.getContainedPotentialTPs(ptp_name, [], FETCH_BULK)
		else:
			allobjs, iterator = mngr.getContainedInUseTPs(ptp_name, [], FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def make_managed_element_name_list(self, nameObjs):
		managedElementName = []
		for key, val in nameObjs.items():
			managedElementName.append(globaldefs.NameAndStringValue_T(name=key, value=val))
		return managedElementName	

	def make_name_list(self, nameObjs):
		managedElementName = []
		for key, val in nameObjs:
			managedElementName.append(globaldefs.NameAndStringValue_T(name=key, value=val))
		return managedElementName
