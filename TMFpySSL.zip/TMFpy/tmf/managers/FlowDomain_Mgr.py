from tmf.tmfutility import *

class FlowDomain:

	def getAllFlowDomains(self, mngr, return_corba_obj = 0):
		allobjs, iterator = mngr.getAllFlowDomains(FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs



	def getFlowDomainsByUserLabel(self, mngr, userLabel = '', return_corba_obj = 0):
		allobjs = mngr.getAllFlowDomains(userLabel)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs




	def getFlowDomain(self, mngr, fdName = [], return_corba_obj = 0):
		allobjs = mngr.getFlowDomain(fdName)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs



	def getAssociatingFD(self, mngr, mfdName = [], return_corba_obj = 0):
		allobjs = mngr.getAssociatingFD(mfdName)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs



	def getTransmissionParams(self, mngr, name = [], filter_list = [], return_corba_obj = 0):
		allobjs = mngr.getTransmissionParams(name, filter_list)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs



	def getAllAssociatedMFDs(self, mngr, tmdOrFdName = [], return_corba_obj = 0):
		allobjs, iterator = mngr.getAllAssociatedMFDs(tmdOrFdName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs



	def getAllSupportedMFDs(self, mngr, holderName = [], return_corba_obj = 0):
		allobjs, iterator = mngr.getAllSupportedMFDs(holderName, FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs	




	def getMFD(self, mngr, mfdName = [], return_corba_obj = 0):
		allobjs = mngr.getMFD(mfdName)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs

	def getAssigningMFD(self, mngr, cptpName = [], return_corba_obj = 0):
		allobjs = mngr.getAssigningMFD(cptpName)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs

	def getAllCPTPs(self, mngr, fdName=[],cptpRole=[],return_corba_obj=0):
		allobjs, iterator = mngr.getAllCPTPs(fdName,cptpRole,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllAssignedCPTPs(self, mngr, mfdName = [], return_corba_obj=0):
		allobjs, iterator = mngr.getAllAssignedCPTPs(mfdName,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllAssignableCPTPs(self, mngr, mfdName = [], return_corba_obj=0):
		allobjs, iterator = mngr.getAllAssignableCPTPs(mfdName,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllFDFrs(self, mngr, fdName = [], connectivityRateList = [], return_corba_obj=0):
		allobjs, iterator = mngr.getAllFDFrs(fdName, 1, connectivityRateList)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getFDFrsWithTP(self, mngr, cptpName = [], return_corba_obj=0):
		allobjs, iterator = mngr.getFDFrsWithTP(cptpName,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getFDFrsByUserLabel(self, mngr, userLabel='', return_corba_obj=0):
		allobjs = mngr.getFDFr(userLabel)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs

	def getFDFr(self, mngr,fdfrName=[], return_corba_obj=0):
		allobjs = mngr.getFDFr(fdfrName)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs
	

	def getAllTopologicalLinksOfFD(self, mngr, flowDomainName = [],return_corba_obj=0):
		allobjs, iterator = mngr.getAllTopologicalLinksOfFD(flowDomainName,FETCH_BULK)
		if iterator:
			more = True
			while more:
				more, iterobjs = iterator.next_n(FETCH_BULK)
				allobjs.extend(iterobjs)
				if not more:
					break
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getFDFrRoute(self, mngr,fdfrName=[], return_corba_obj=0):
		allobjs = mngr.getFDFrRoute(fdfrName)
		if not return_corba_obj:
			return corbaObjToDict(allobjs)
		else:
			return allobjs
