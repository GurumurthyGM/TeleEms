import os
import inspect
import importlib
from tmfutility import *

TMFscannerMap = {}
TMFmanagerMap = {}


def get_scanners(module_reload=0):
    global TMFscannerMap
    if TMFscannerMap and not module_reload:
        return TMFscannerMap
    path = os.path.dirname(os.path.abspath(__file__)) + os.sep + 'apiinterface'
    print "\ntmf api scanner path >> ", path
    ret = []
    scannerToTry = {}
    for scanner in os.listdir(path):
        _scanner, ext = splitLeft(string.lower(scanner), '.')
        if _scanner == "__init__":
            continue
        if ext in ['py', 'pyc']:
            scannerToTry[_scanner] = 'tmf.apiinterface.%s' % _scanner
    for scanner, module_path in scannerToTry.iteritems():
        # print "tmf api module_path >> ",module_path
        if scanner not in TMFscannerMap or module_reload:
            try:
                module = importlib.import_module(module_path)
                iname, inst = module.getInterface()
                TMFscannerMap[iname] = inst
            # print "\ninitiaized inst >> ",inst
            except:
                print(4, "***** Cannot intialize tmf scanner module for %s. *****" % module_path, "General")
    return TMFscannerMap


def get_managers():
    global TMFmanagerMap
    if TMFmanagerMap:
        return TMFmanagerMap
    manager_list = []
    path = os.path.dirname(os.path.abspath(__file__)) + os.sep + 'managers'
    print "\ntmf managers path >> ", path
    for fname in os.listdir(path):
        _manager, ext = splitLeft(fname, '.')
        if _manager == "__init__":
            continue
        if ext in ['py', 'pyc'] and _manager not in manager_list:
            manager_list.append(_manager)

    for fname in os.listdir(path):
        _manager, ext = splitLeft(fname, '.')
        if _manager == "__init__":
            continue
        if ext in ['py', 'pyc']:
            try:
                module_path = 'tmf.managers.%s' % _manager
                # print "tmf manager path >> ",module_path
                module = (importlib.import_module(module_path))
                for className, classInst in inspect.getmembers(module, inspect.isclass):
                    data_string = str(classInst)
                    module_list = data_string.split('.')
                    if len(module_list) < 2:
                        continue
                    module_name = module_list[-2]
                    if module_name in manager_list:
                        TMFmanagerMap.update({className: classInst()})
            except:
                print(4, "***** Cannot intialize tmf manager module for %s. *****" % module_path, "General")
    return TMFmanagerMap
