import os
import string
import sys
import inspect
import time
from traceback import print_exc
from tmf.idlc_tmf_v35 import multiLayerSubnetwork_idl

# uncomment to enbale SSL
from omniORB.sslTP import *
certificate_authority_file("/root/TMFpy/SSLKEY/tejems.pem")
key_file("/root/TMFpy/SSLKEY/tejems.pem")
key_file_password("iltwat")
print_traceback = print_exc
##################################

path = os.path.dirname(os.path.abspath(__file__))
sys.path.append(path + os.sep + 'idlc_tmf_v35' + os.sep)
print "\nTMF Library Module path ------- >> %s " % path + os.sep + 'idlc_tmf_v35' + os.sep

FETCH_BULK = 40

# load Omniorb lib modules
try:
    import emsMgr
    import emsSessionFactory
    import nmsSession, nmsSession__POA
    import notifications, notifications__POA
    import managedElement
    import managedElementManager
    import flowDomain
    import protection
    import performance
    import topologicalLink
    import equipment
    import globaldefs
    import subnetworkConnection
    import multiLayerSubnetwork
    import terminationPoint
    import transmissionParameters
    import CosNaming
    import CosNotification
    import trafficConditioningProfile
    import CosNotifyComm__POA
    import CosNotifyChannelAdmin
    import common
    from omniORB import CORBA

except Exception, msg:
    class _CORBA(object):
        def __init__(self):
            self.OBJECT_NOT_EXIST = ''
            self.BAD_INV_ORDER = ''


    CORBA = _CORBA()
    print "\nException, msg >> ", Exception, msg
    print "**** Omniorb Library Not Loaded ****"

try:
    class NmsSession_I(nmsSession__POA.NmsSession_I):
        pass


    exclude_probableCause_list = []
    #  PS_INDETERMINATE, 0
    #  PS_CRITICAL, 1
    #  PS_MAJOR, 2
    #  PS_MINOR, 3
    #  PS_WARNING, 4
    #  PS_CLEARED 5
    # perceivedSeverity = []
    perceivedSeverity = [notifications.PS_INDETERMINATE,
                         notifications.PS_CRITICAL,
                         notifications.PS_MAJOR,
                         notifications.PS_MINOR,
                         notifications.PS_WARNING,
                         notifications.PS_CLEARED,
                         ]
    exclude_perceivedSeverity_list = CORBA.Any(notifications._tc_PerceivedSeverityList_T, perceivedSeverity)
except:
    print "**** Corba classes not initialized ****"
    pass


def dummyCallbackFunction(*args, **kwargs):
    pass


def execScanFunc(inst, scanner, method, args=[], kwargs={}, recreate_session_on_retry=1):
    try:
        mgrs = inst.getManagers()
        if not args:
            args = [mgrs]
        else:
            if recreate_session_on_retry:  # first execution
                args = list(args)
                args.insert(0, mgrs)
            else:
                args[0] = mgrs
        st = time.time()
        out = getattr(scanner, method)(*args, **kwargs)
        elapsed = time.time() - st
        # print "Execute Completed for %s, method - %s, elapsed - %s" % (inst.corba_ip, str(method), elapsed)
        print(4, "Execution Completed for %s, method - %s, elapsed - %s" % (inst.corba_ip, str(method), elapsed))
        return out
    except CORBA.OBJECT_NOT_EXIST:
        if recreate_session_on_retry:
            print(4, "Session corrupted (OBJECT_NOT_EXIST)- Recreating session for - %s" % inst.corba_ip)
            print "Session corrupted (OBJECT_NOT_EXIST) - Recreating session for - %s" % inst.corba_ip
            try:
                inst.reconnect()
            except:
                return None
            return execScanFunc(inst, scanner, method, args, kwargs, recreate_session_on_retry=0)
    except CORBA.BAD_INV_ORDER:
        if recreate_session_on_retry:
            print(4, "Session corrupted (BAD_INV_ORDER) - Recreating session for - %s" % inst.corba_ip)
            print "Session corrupted (BAD_INV_ORDER) - Recreating session for - %s" % inst.corba_ip
            try:
                inst.reconnect()
            except:
                return None
            return execScanFunc(inst, scanner, method, args, kwargs, recreate_session_on_retry=0)
    except CORBA.TRANSIENT:
    	if recreate_session_on_retry:
    		print(4, "Session corrupted (TRANSIENT) - Recreating session for - %s" % inst.corba_ip)
    		print "Session corrupted (TRANSIENT) - Recreating session for - %s" % inst.corba_ip
    		try:
    			inst.reconnect()
    		except:
    			return None
    		return execScanFunc(inst, scanner, method, args, kwargs, recreate_session_on_retry = 0)
    except Exception, msg:
        print "Error[0] : "
        print "Exception %s - %s - %s - %s " % (inst.corba_ip, str(method), str(Exception), str(msg))
        print_exc()
        print(4, "Exception %s - %s - %s - %s " % (inst.corba_ip, str(method), str(Exception), str(msg)))
    except:
        print "Error[1] : "
        print_exc()
        print(4, "Exception in execScanFunc - %s - %s" % (inst.corba_ip, str(method)))
    return None


class CorbaInterface:

    def __init__(self, corba_ip, corba_port, user, pwd, ems_name="", ior=None, name_context=[]):
        self.ems_session_factory = None
        self.ems_session = None
        self.orb = None
        self.mgr_map = {}
        self.capabilities = {}
        self.corba_ip = corba_ip
        self.corba_port = corba_port
        self.ems_name = ems_name
        self.username = user
        self.password = pwd
        self.ior = ior
        self.name_context = name_context
        if not (self.ior or self.name_context):
            print(4, "Unable to connect through Corba, %s - IOR or Name context required [0]" % self.corba_ip)
            return

    def reconnect(self):
        self.endSession()
        self.connect()

    def endSession(self):
        try:
            self.ems_session.endSession()
        except:
            pass
        try:
            self.orb.destroy()
        except:
            pass
        try:
            del self.ems_session_factory
            del self.ems_session
            del self.orb
            del self.mgr_map
        except:
            print_exc()
            print(4, "Exception in clearing self variables - %s" % self.corba_ip)
        self.ems_session_factory = None
        self.ems_session = None
        self.orb = None
        self.mgr_map = {}
        print("Clossed the connection!")

    def connect(self):
        try:
            if self.ior:
                self.orb = CORBA.ORB_init([], CORBA.ORB_ID)
                obj = self.orb.string_to_object(self.ior)
                self.ems_session_factory = obj._narrow(emsSessionFactory.EmsSessionFactory_I)
                nms_session_i = NmsSession_I()
                nms_session_o = nms_session_i._this()
                self.ems_session = self.ems_session_factory.getEmsSession(self.username, self.password, nms_session_o)
            elif self.name_context:
                self.orb = None
                if not self.ems_session_factory:
                    st = time.time()
                    self.createEMSSessionFactory()
                    print(4, "Corba Factory Initialized, %s - Elapsed - %s" % (self.corba_ip, time.time() - st))
                if not self.ems_session_factory:
                    self.ems_session = None
                    print(4,
                          "Unable to connect through Corba, %s -  Cannot create session, EmsSessionFactory_I not available" % self.corba_ip)
                else:
                    nms_session_i = NmsSession_I()
                    nms_session_o = nms_session_i._this()
                    st = time.time()
                    ems_session = self.ems_session_factory.getEmsSession(self.username, self.password, nms_session_o)
                    if ems_session is None:
                        print(4, "Unable to connect through Corba, %s - Cannot create session" % self.corba_ip)
                    else:
                        self.ems_session = ems_session
                        print(4, "Corba EmsSession Created, %s - Elapsed - %s" % (self.corba_ip, time.time() - st))
            else:
                self.endSession()
                print(4, "Unable to connect through Corba, %s - IOR or Name context required [1]" % self.corba_ip)
        except:
            self.endSession()
            print_exc()
            print(4, "Unable to connect through Corba")

    def createEMSSessionFactory(self):
        try:
            # For non SSL
            #argv = ["-ORBInitRef", "NameService=corbaloc::%s:%s/NameService" % (self.corba_ip, self.corba_port), "-ORBtraceLevel", '25']
            # For SSL enabled
            argv = ["-ORBInitRef", "NameService=corbaloc:ssliop:1.2@%s:%s/NameService" % (self.corba_ip, self.corba_port), "-ORBtraceLevel", '25', "-ORBsslVerifyMode", "none"]
            
            self.orb = CORBA.ORB_init(argv, CORBA.ORB_ID)
            print time.ctime(), self.orb, "<<<< 11"
            ### Obtain a reference to the root naming context
            
            obj = self.orb.resolve_initial_references("NameService")
            print time.ctime(), obj, "<<<< 22"
            rootContext = obj._narrow(CosNaming.NamingContext)
            #rootContext = obj._unchecked_narrow(CosNaming.NamingContext)
            print time.ctime(), rootContext, "<<<< 33"
            if rootContext is None:
                print("Failed -> narrow the root naming context")
            ### Resolve the name
            print time.ctime(), "Resolving Name..."
            print(4, "Resolving Name...")
            try:
                obj = rootContext.resolve(self.name_context)
            except CosNaming.NamingContext.NotFound as ex:
                print "Except -> Name not found"
                print ex
            # print time.ctime(), "Name Component resolved.", obj, "<<<< 44"
            print(4, "Corba Name Component resolved, %s" % self.corba_ip)
            ### Narrow the object
            ems_session_factory = obj._narrow(emsSessionFactory.EmsSessionFactory_I)
            if ems_session_factory is None:
                raise Exception, "Error -> Object reference is not an EmsSessionFactory_I"
            else:
                self.ems_session_factory = ems_session_factory
        except Exception, msg:
            print  "Fatal Error - Cannot create EmsSessionFactory_I", Exception, msg
            print_exc()
                        
        except:
            print "Fatal Error - Cannot create EmsSessionFactory_I ** "

    def getManagers(self, required_list=[]):
        if not self.mgr_map:
            self.LoadManagers(required_list)
        return self.mgr_map

    def LoadManagers(self, required_list=[]):
        try:
            if self.ems_session:
                manager_list = self.ems_session.getSupportedManagers()
                print '\nSupported manager list >> ', manager_list, "\n"
                if not required_list:
                    required_list = manager_list
                if 'ManagedElement' in manager_list and 'ManagedElement' in required_list:
                    mn_elm = self.ems_session.getManager("ManagedElement")
                    mn_elm_mgr = mn_elm._narrow(managedElementManager.ManagedElementMgr_I)
                    self.mgr_map['ManagedElement'] = mn_elm_mgr
                # self.updateCapabilities(mn_elm_mgr, 'ManagedElement')
                if 'EMS' in manager_list and 'EMS' in required_list:
                    ems = self.ems_session.getManager("EMS")
                    self.mgr_map['EMS'] = ems
                if 'EquipmentInventory' in manager_list and 'EquipmentInventory' in required_list:
                    inv_elm = self.ems_session.getManager("EquipmentInventory")
                    inv_elm_mgr = inv_elm._narrow(equipment.EquipmentInventoryMgr_I)
                    self.mgr_map['EquipmentInventory'] = inv_elm_mgr
                if 'MultiLayerSubnetwork' in manager_list and 'MultiLayerSubnetwork' in required_list:
                    subnetwork_elm = self.ems_session.getManager("MultiLayerSubnetwork")
                    subnetwork_elm_mgr = subnetwork_elm._narrow(multiLayerSubnetwork.MultiLayerSubnetworkMgr_I)
                    self.mgr_map['MultiLayerSubnetwork'] = subnetwork_elm_mgr
                if 'FlowDomain' in manager_list and 'FlowDomain' in required_list:
                    flow_domain = self.ems_session.getManager("FlowDomain")
                    flow_domain_mgr = flow_domain._narrow(flowDomain.FlowDomainMgr_I)
                    self.mgr_map['FlowDomain'] = flow_domain_mgr
                if 'Protection' in manager_list and 'Protection' in required_list:
                    protection_elm = self.ems_session.getManager("Protection")
                    protection_mgr = protection_elm._narrow(protection.ProtectionMgr_I)
                    self.mgr_map['Protection'] = protection_mgr
                if 'PerformanceManagement' in manager_list and 'PerformanceManagement' in required_list:
                    performance_elm = self.ems_session.getManager("PerformanceManagement")
                    perf_mgr = performance_elm._narrow(performance.PerformanceManagementMgr_I)
                    self.mgr_map['PerformanceManagement'] = perf_mgr
                if 'TCProfile' in manager_list and 'TCProfile' in required_list:
                    tc_profile = self.ems_session.getManager("TCProfile")
                    tc_profile_mgr = tc_profile._narrow(trafficConditioningProfile.TCProfileMgr_I)
                    self.mgr_map['TCProfile'] = tc_profile_mgr

            else:
                print 'Invalid EMS Session.'
        except:
            print_exc()

    def updateCapabilities(self, mgr, mgr_name):
        try:
            out = []
            objs = mgr.getCapabilities()
            objs = corbaObjToDict(objs)
            for obj in objs:
                supported = obj.get('name').split(':')[-1]
                if obj.get('value').lower() == 'supported':
                    out.append(supported)
            self.capabilities[mgr_name] = out
        except:
            print_exc()
            self.capabilities[mgr_name] = None


def getObjClassAll(ins):
    try:
        return ins.__class__.__name__
    except:
        return ''


def getObjClass(ins):
    try:
        class_name = ins.__class__.__name__
        if class_name not in ('list', 'dict', 'str', 'unicode', 'int', 'float', 'bool', 'tuple'):
            return class_name
        return ''
    except:
        return ''


def sanitizeStr(estr):
    try:
        return filter(lambda x: x in string.printable, estr)
    except:
        try:
            return string.join(
                map(lambda a: chr(a), filter(lambda a: a > 31 or a in [9, 10, 13], map(lambda a: ord(a), estr))), "")
        except:
            return str(estr)
    return str(estr)


def splitLeft(x, param):
    return x.split(param, 1)


def holderToDict(dat):
    try:
        return dict([splitLeft(x, "=") for x in dat.split('/') if x])
    except:
        print(4, "Exception in holderToDict function.")
        return {}


def is_equipment(elem):
    return hasattr(elem, 'equip')


def is_holder(elem):
    return hasattr(elem, 'holder')


def nameObjToDict(elementNames):
    name_dict = dict()
    if type(elementNames) not in [type([]), type(())]:
        elementNames = [elementNames]
    try:
        for elemName in elementNames:
            if not (type(elemName) == type([])):
                class_name = getObjClass(elemName)
                if class_name == 'NameAndStringValue_T':
                    if inspect.isclass(elemName.value):
                        name_dict[str(elemName.name)] = corbaObjToDict(elemName.value)
                    else:
                        name_dict[str(elemName.name)] = sanitizeStr(elemName.value)
                elif class_name == 'Property':
                    if getObjClass(elemName.value) == 'Any':
                        if type(elemName.value._v) == type([]):
                            name_dict[str(elemName.name)] = nameObjToDict(elemName.value._v)
                        else:
                            name_dict[str(elemName.name)] = sanitizeStr(elemName.value._v)
                    else:
                        name_dict[str(elemName.name)] = sanitizeStr(elemName.value)
                elif class_name:
                    # print class_name, "<<< class_name"
                    name_dict[class_name] = corbaObjToDict(elemName)
                else:
                    print "\nErrorr - Cant parse Element[0] - %s" % sanitizeStr(elemName)
            else:
                for elem in elemName:
                    class_name = getObjClass(elem)
                    # print class_name, elem
                    if class_name == 'NameAndStringValue_T':
                        if inspect.isclass(elem.value):
                            name_dict[str(elem.name)] = corbaObjToDict(elem.value)
                        else:
                            name_dict[str(elem.name)] = sanitizeStr(elem.value)
                    elif class_name == 'Property':
                        if getObjClass(elem.value) == 'Any':
                            if type(elem.value._v) == type([]):
                                name_dict[str(elem.name)] = nameObjToDict(elem.value._v)
                            else:
                                name_dict[str(elem.name)] = sanitizeStr(elem.value._v)
                        else:
                            name_dict[str(elem.name)] = sanitizeStr(elem.value)
                    elif class_name:
                        name_dict[class_name] = corbaObjToDict(elem)
                    else:
                        print "\nErrorr - Cant parse Element[1] - %s" % sanitizeStr(elem)
    except:
        print(4, "Exception in nameObjToDict")
        print_exc()
    return name_dict


def corbaObjToDict(obj):
    # print "\nobj >> ",obj
    objDict = dict()
    if obj is None:
        return
    try:
        if type(obj) == type({}):
            tObj = obj
        elif type(obj) in [type([]), type(())]:
            out = []
            for ob in obj:
                out.append(corbaObjToDict(ob))
            return out
        else:
            tObj = obj.__dict__
            if getObjClass(obj) and getObjClass(obj) not in ('NameAndStringValue_T', 'Property', 'EnumItem'):
                tObj['structType'] = getObjClass(obj)
        if tObj.has_key('_v'):
            n = tObj.get('_n')
            structType = tObj.get('structType', '')
            tObj = tObj['_v']
            if getObjClassAll(tObj) in ('str', 'unicode', 'int', 'float', 'bool'):
                out = {n: tObj}
                if structType and structType not in ('NameAndStringValue_T', 'Property', 'EnumItem'):
                    out[n]['structType'] = structType
                return out
            elif type(tObj) != type({}):
                tObj = tObj.__dict__
                if structType and structType not in ('NameAndStringValue_T', 'Property', 'EnumItem'):
                    tObj['structType'] = structType
        for key, value in tObj.iteritems():
            class_name = getObjClass(value)
            if key.startswith('_'): continue
            if not value:
                objDict[str(key)] = value
            elif type(value) == type([]):
                if value and getObjClassAll(value[0]) in ('str', 'unicode', 'int', 'float', 'bool'):
                    objDict[str(key)] = value
                elif getObjClassAll(value[0]) in ('NameAndStringValue_T', 'Property'):
                    objDict[str(key)] = nameObjToDict(value)
                else:
                    objDict[str(key)] = []
                    for _v in value:
                        objDict[str(key)].append(corbaObjToDict(_v))
            elif inspect.isclass(value):
                objDict[str(key)] = corbaObjToDict(value)
            elif class_name == 'Any':
                if type(value._v) == type([]):
                    objDict[str(key)] = nameObjToDict(value._v)
                else:
                    objDict[str(key)] = sanitizeStr(value._v)
            elif class_name == 'EventHeader':
                if value.__dict__.get('fixed_header'):
                    temp = dict()
                    objDict['fixed_header'] = dict()
                    for k, v in value.__dict__.get('fixed_header').__dict__.iteritems():
                        if type(v) == type(''):
                            objDict['fixed_header'][k] = sanitizeStr(v)
                        else:
                            objDict['fixed_header'][k] = v.__dict__
                            if getObjClass(v):
                                if getObjClass(v) not in ('NameAndStringValue_T', 'Property', 'EnumItem'):
                                    objDict['structType'] = getObjClass(v)
            elif class_name:
                objDict[str(key)] = corbaObjToDict(value)
            else:
                objDict[str(key)] = sanitizeStr(value)
    except:
        print(4, "Exception in corbaObjToDict")
        print_exc()
    return objDict


def make_managed_element_name(nameObjs,
                              name_order=['EMS', 'ManagedElement', 'MLRA', 'MLSNPPLink', 'TopologicalLink', 'PTP',
                                          'FTP', 'MultiLayerSubnetwork', 'SubnetworkConnection', 'CTP'], corba_obj=0):
    managedElementName = []
    for ename in name_order:
        if ename in nameObjs:
            managedElementName.append(globaldefs.NameAndStringValue_T(name=ename, value=nameObjs[ename]))
    if len(nameObjs) != len(managedElementName):
        # find missed keys
        print "\n-- add missing key --\n", nameObjs, '\n', managedElementName
        for key, val in nameObjs.items():
            if key not in name_order:
                print key
                managedElementName.append(globaldefs.NameAndStringValue_T(name=key, value=val))
    if not corba_obj:
        return managedElementName
    else:
        return CORBA.Any(globaldefs._tc_NamingAttributes_T, managedElementName)


def parseJKLMString(str1):
    data = {}
    try:
        parts = str1.split('/')
        data['label'] = []
        for part in parts:
            parts1 = part.split('-')
            for part1 in parts1:
                part1 = part1.strip()
                if part1.find('=') != -1:
                    x, y = splitLeft(part1, '=')
                    data[x] = y
                elif part1:
                    data['label'].append(part1)
        if len(data['label']) > 1:
            vc = data['label'][-1]
            if vc.find('tu12') != -1:
                data['capacity'] = 'VC12'
            elif vc.find('tu11') != -1:
                data['capacity'] = 'VC11'
            elif vc.find('vt2') != -1:
                data['capacity'] = 'VC2'
            elif vc.find('vt3') != -1:
                data['capacity'] = 'VC3'
            elif len(data['label']) == 1:
                vc = data['label'][-1]
                if vc.find('au4') != -1:
                    data['capacity'] = 'VC4'
                else:
                    data['capacity'] = ''
        data['label'] = '|'.join(data['label'])
    except:
        print_exc()
    return data


def parsePTPIdentifier(str1):
    return dict([splitLeft(d, '=') for d in str1.split('/') if d.strip().find('=') != -1])

EMSFree = multiLayerSubnetwork_idl._0_multiLayerSubnetwork.EMSFL_CC_AT_SNC_LAYER

if __name__ == '__main__':
    # corba_query = connect()
    # ems_session_factory = corba_query.ems_session_factory
    # ems_session = corba_query.ems_session
    # result = get_all_inventory_data(ems_session_factory, ems_session)
    print 'Completed...'
# f = open(corba_query.corba_ip + '.txt', 'w+')
# print json.dumps(result, indent=4)
# f.write(json.dumps(result, indent=4))
# f.close()
