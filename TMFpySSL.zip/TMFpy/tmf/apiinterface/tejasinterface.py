import json

from tmf.idlc_tmf_v35 import CosNaming, flowDomain
from tmf.tmfutility import *
from tmf.base_scanner import BaseTMFScanner


def getInterface():
    return "TEJAS", TEJASCorbaInterface()


class TEJASCorbaInterface(BaseTMFScanner):

    def __init__(self):
        self.scan_vne = True

    def getDeviceVendor(self, obj={}):
        return 'Tejas Networks'

    def getDeviceModel(self, obj={}):
        return 'Tejas'

    def getDeviceType(self, obj={}):
        return 'EMS'

    def getNameContext(self, emsname, version='3.5', vendor='TejasNetworks'):
        namecontext = [
            CosNaming.NameComponent("TMF_MTNM", "Class"),
            CosNaming.NameComponent(str(vendor), "Vendor"),
            CosNaming.NameComponent("%s/%s" % (vendor, emsname), "EmsInstance"),
            CosNaming.NameComponent(str(version), "Version"),
            CosNaming.NameComponent("TejasNetworks/%s" % emsname, "EmsSessionFactory_I")
        ]
        return namecontext

    def getOSName(self):
        return 'Tejas OS'

    def getOSVersion(self):
        return '1.0'

    def getPTPName(self, obj={}):
        return obj.get('nativeEMSName', '-NA-')

    def isVNE(self, obj):
        if str(obj.get("productName")) == "VNE" or str(obj.get("additionalInfo", {}).get("VNE")) in ("true", "True"):
            return True
        return False

    def scanNE(self, inst, ne, discovery_options={}, dump_to_folder=''):
        scannerInst = self
        outfolder = dump_to_folder + os.sep + inst.corba_ip
        if not discovery_options:
            discovery_options = {'equipments': 1, 'ptp': 1, 'ctp': 0, 'topology': 0,
                                 'crossconnect': 0, 'snc': 0, 'sncroute': 0}
        if discovery_options.get('ctp') or discovery_options.get('topology') or discovery_options.get('snc'):
            discovery_options['ptp'] = 1
        if discovery_options.get('topology') or discovery_options.get('sncroute'):
            discovery_options['snc'] = 1
        result = {}
        EQUIPMENTS = []
        PTPS = []
        CTP = {}
        SNC = {}
        TOPO = {}
        ROUTES = {}
        CROSS_CONNECTS = []
        ip = scannerInst.getIPAddress(ne)
        st = time.time()
        isValidIP = True
        try:
            print "\n%s | IP : %s" % (time.ctime(), ip)
            if not isValidIP:
                raise Exception("Invalid IP : %s" % str(ip))
            # if ip not in ['192.9.146.1','192.9.144.231']:
            # 	return {}
            identifier = ne.get('name', ne.get('identifier', {}))
            meName = make_managed_element_name(identifier)
            # print "meName >", meName
            # topology_links = execScanFunc(inst, scannerInst, 'getTopology', ())
            # print len(topology_links), "<< topology_links"
            # return
            if discovery_options.get('equipments'):
                EQUIPMENTS = execScanFunc(inst, scannerInst, 'getAllEquipment', (meName,))
                print '%s | EQUIPMENT Len >> %s' % (time.ctime(), len(EQUIPMENTS))
            if discovery_options.get('ptp'):
                PTPS = execScanFunc(inst, scannerInst, 'getAllPTPs', (meName,))
                print '%s | PTP Len >> %s' % (time.ctime(), len(PTPS))
            indx = 0
            for ptp in PTPS:
                indx += 1
                ptpidentifier = ptp.get('name')
                ptpLabel = ptpidentifier.get('PTP', ptpidentifier.get('FTP'))
                ptpName = make_managed_element_name(ptpidentifier)
                # print ptpName
                if discovery_options.get('ctp'):
                    ctps = execScanFunc(inst, scannerInst, 'getContainedPotentialTPs', (ptpName,))
                    if ctps:
                        CTP[ptpLabel] = ctps
                sncs = []
                if discovery_options.get('snc'):
                    sncs = execScanFunc(inst, scannerInst, 'getAllSubnetworkConnectionsWithTP', (ptpName,))
                if sncs:
                    print '	%s | [%s] SNC Len >> %s' % (time.ctime(), indx, len(sncs))
                    SNC[ptpLabel] = sncs
            routes_len, topo_len = 0, 0
            for ptpLabel, sncs in SNC.iteritems():
                for snc in sncs:
                    sncidentifier = snc.get('name')
                    sncName = make_managed_element_name(sncidentifier)
                    sncLabel = sncidentifier.get('SubnetworkConnection')
                    if discovery_options.get('sncroute') or discovery_options.get('topology'):
                        routes, topos = execScanFunc(inst, scannerInst, 'getRouteAndTopologicalLinks', (sncName,))
                        if routes:
                            ROUTES[sncLabel] = routes
                            routes_len += len(routes)
                        if topos:
                            TOPO[sncLabel] = topos
                            topo_len += len(topos)
                    """
					if discovery_options.get('sncroute'):
						routes = execScanFunc(inst, scannerInst, 'getRoute', (sncName, ))
						if routes:
							ROUTES[sncLabel] = routes 
							print len(routes), "<< routes"
					if discovery_options.get('topology'):
						topos = execScanFunc(inst, scannerInst, 'getAllTopologicalLinks', (sncName,))					
						if topos:
							TOPO[sncLabel] = topos
							print len(topos), "<< topos"
					"""
            print '%s | Routes Len >> %s' % (time.ctime(), routes_len)
            print '%s | Topo Len >> %s' % (time.ctime(), topo_len)
            if discovery_options.get('crossconnect'):
                CROSS_CONNECTS = execScanFunc(inst, scannerInst, 'getAllCrossConnections', (meName,))
                print '%s | CROSS_CONNECTS Len >> %s' % (time.ctime(), len(CROSS_CONNECTS))
        except:
            print(4, "Exception in scanning individual NE", "General")
        finally:
            print "Elapsed -> %s\n" % str(time.time() - st)

        if EQUIPMENTS: result['EQUIPMENTS'] = EQUIPMENTS
        if PTPS: result['PTPS'] = PTPS
        if CTP:    result['CTP'] = CTP
        if SNC:    result['SNC'] = SNC
        if TOPO: result['TOPO'] = TOPO
        if ROUTES: result['ROUTES'] = ROUTES
        if CROSS_CONNECTS: result['CROSS_CONNECTS'] = CROSS_CONNECTS
        print "dump_to_folder >> ", outfolder
        if dump_to_folder and isValidIP:
            try:
                result['discovery_time'] = time.ctime()
                result['discovery_timestamp'] = time.time()
                with open(outfolder + os.sep + '%s.txt' % ip, 'w+') as f:
                    f.write('%s' % json.dumps(result, indent=4))
                    print "Stored %s data in folder %s" % (ip, dump_to_folder)
            except:
                pass
        return result

    def getTrunkType(self, obj={}):
        return obj.get('additionalInfo', {}).get('Trunk_Type', '')

    def formTopologyObj(self, tobj, res_map={}, nemap={}):
        aEndTP = tobj.get('aEndTP', {}).get('PTP', '')
        aEndIP = tobj.get('aEndTP', {}).get('ManagedElement', '')
        zEndTP = tobj.get('zEndTP', {}).get('PTP', '')
        zEndIP = tobj.get('zEndTP', {}).get('ManagedElement', '')
        r1obj = res_map.get('%s__%s' % (aEndIP, aEndTP))
        r2obj = res_map.get('%s__%s' % (zEndIP, zEndTP))
        obj = dict()
        if r1obj and r2obj:
            obj['name'] = tobj.get('name', {}).get('TopologicalLink', '')
            obj['reltype'] = 1
            obj['aEndIP'] = aEndIP
            obj['aEndTP'] = aEndTP
            obj['zEndIP'] = zEndIP
            obj['zEndTP'] = zEndTP
            obj['nodeid1'] = r1obj.get('nodeid', -1)
            obj['nodeid2'] = r2obj.get('nodeid', -1)
            obj['resid1'] = r1obj.get('resid', -1)
            obj['resid2'] = r2obj.get('resid', -1)
            obj['descr'] = "AutoTopoTMF"
            obj['show_on_flatview'] = 1
            obj['conn_type'] = 'Fiber'
            obj['trunk_type'] = str(tobj.get('additionalInfo', {}).get('Trunk_Type', ''))
            if obj['trunk_type'] == 'OSC_TRUNK':
                obj['reltype'] = 3
        return obj

    def getAllPTPsCTPsforME(self, managers, meName, tpLayerRateList=[], connectionLayerRateList=[], ctp=1,
                            return_corba_obj=0):
        if 'ManagedElement' not in managers:
            print(4, "No manager - ManagedElement")
            return []
        manager = managers['ManagedElement']
        allobjs, iterator = manager.getAllPTPs(meName.value(), tpLayerRateList, connectionLayerRateList, FETCH_BULK)
        if iterator:
            more = True
            while more:
                more, iterobjs = iterator.next_n(FETCH_BULK)
                allobjs.extend(iterobjs)
                if not more:
                    break
        if ctp:
            out = []
            for ptp in allobjs:
                allCTPobjs, iterator = manager.getContainedPotentialTPs(ptp.name, [], FETCH_BULK)
                # allCTPobjs, iterator = manager.getContainedInUseTPs(ptp.name, [], FETCH_BULK)
                if iterator:
                    more = True
                    while more:
                        more, iterobjs = iterator.next_n(FETCH_BULK)
                        allCTPobjs.extend(iterobjs)
                        if not more:
                            break
                if not return_corba_obj:
                    ptpd = corbaObjToDict(ptp)
                    ptpd['CTP'] = [corbaObjToDict(obj) for obj in allCTPobjs]
                    out.append(ptpd)
                else:
                    setattr(ptp, 'CTP', allCTPobjs)
                    out.append(ptp)
            return out
        else:
            if not return_corba_obj:
                return [corbaObjToDict(obj) for obj in allobjs]
            else:
                return allobjs

    def getAllSubnetworkConnections(self, managers, return_corba_obj=0):
        if 'MultiLayerSubnetwork' not in managers:
            print(4, "No manager - MultiLayerSubnetwork")
            return []
        print '\n getAllSubnetworkConnections...'
        subnetwork_objs = []
        try:
            ems = managers['EMS']
            subnetworks, iterator = ems.getAllTopLevelSubnetworks(FETCH_BULK)
            print "\nsubnetworks >> ", len(subnetworks)
            sub_manager = managers['MultiLayerSubnetwork']
            for subnetwork in subnetworks:
                _subnetwork = corbaObjToDict(subnetwork)
                allobjs = []
                iterobjs, iterator = sub_manager.getAllTopologicalLinks(subnetwork.name, FETCH_BULK)
                print '\n iter_objs -- ', len(iterobjs)
                allobjs.extend(iterobjs)
                if iterator:
                    more = True
                    while more:
                        more, iterobjs = iterator.next_n(FETCH_BULK)
                        print '\n iter_objs -- ', len(iterobjs)
                        allobjs.extend(iterobjs)
                        if not more:
                            break
                _subnetwork['SNCs'] = [corbaObjToDict(obj) for obj in allobjs]
                subnetwork_objs.append(_subnetwork)
        except Exception, msg:
            print Exception, msg
        return subnetwork_objs

    def getAllFDDetails(self, managers, return_corba_obj=0):
        if 'FlowDomain' not in managers:
            print(4, "No manager - FlowDomain")
            return []
        allobjs = []
        try:
            flow_domains = self.getAllFlowDomains(managers, return_corba_obj=1)
            for flow_domain in flow_domains:
                _flow_domain = corbaObjToDict(flow_domain)
                fdfrs = self.getAllFDFrs(flow_domain, managers)
                _flow_domain['FDFr'] = fdfrs
                associated_mfds = self.getAllAssociatedMFDs(flow_domain, managers)
                _flow_domain['associated_mfds'] = associated_mfds
                if _flow_domain.get('fdType', '') != 'FDT_SINGLETON':
                    fd_topology = self.getAllTopologicalLinksOfFD(flow_domain, managers)
                    _flow_domain['FDTopology'] = fd_topology
                # cptps = self.getAllCPTPs(flow_domain, managers)
                # _flow_domain['CPTPs'] = cptps
                allobjs.append(_flow_domain)
        except Exception, msg:
            print 'Exception in getAllFDDetails -- ', Exception, msg
        return allobjs

    def getAllFlowDomains(self, managers, return_corba_obj=0):
        if 'FlowDomain' not in managers:
            print(4, "No manager - FlowDomain")
            return []
        print '\n getAllFlowDomains...'
        allobjs = []
        try:
            ems = managers['FlowDomain']
            iterobjs, iterator = ems.getAllFlowDomains(FETCH_BULK)
            # print 'iterobjs -- ',len(iterobjs), '\n\n', iterobjs[0]
            allobjs.extend(iterobjs)
            if iterator:
                more = True
                while more:
                    more, iterobjs = iterator.next_n(FETCH_BULK)
                    print '\n iter_objs -- ', len(iterobjs)
                    allobjs.extend(iterobjs)
                    if not more:
                        break
        except Exception, msg:
            print Exception, msg
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllFDFrs(self, flow_domain, managers, return_corba_obj=0):
        if 'FlowDomain' not in managers:
            print(4, "No manager - FlowDomain")
            return []
        try:
            allobjs = []
            fd_name = flow_domain.name
            print 'fd_name -- ', fd_name
            ems = managers['FlowDomain']
            counter = 1
            iterobjs, iterator = ems.getAllFDFrs(fd_name, 10, [])
            # for iterobj in iterobjs:
            # 	print '\n\n\n', iterobj, '\n\n\n'
            counter += 1
            allobjs.extend(iterobjs)
            if iterator:
                more = True
                while more:
                    print 'getting next 10...', counter
                    more, iterobjs = iterator.next_n(10)
                    counter += 1
                    allobjs.extend(iterobjs)
                    if not more:
                        break
        except Exception, msg:
            print Exception, msg
        fdfrs = []
        for fdfr in allobjs:
            _fdfr = corbaObjToDict(fdfr)
            if flow_domain.fdType != 'FDT_SINGLETON':
                fdfr_route = self.getFDFrRoute(fdfr, managers)
                _fdfr['FDFrRoute'] = fdfr_route
            fdfrs.append(_fdfr)
        return fdfrs

    def getFDFrRoute(self, fdfr, managers, return_corba_obj=0):
        if 'FlowDomain' not in managers:
            print(4, "No manager - FlowDomain")
            return []
        print '\n\n getFDFrRoute...', fdfr.name
        allobjs = []
        try:
            if fdfr:
                ems = managers['FlowDomain']
                fdfr_name = fdfr.name
                # fdfr_route = ems.getFDFrRoute(fdfr_name)
                tp_params = ems.getTransmissionParams(fdfr_name, [])
                # allobjs.extend(fdfr_route)
                allobjs.extend(tp_params)
                print 'FDFR Route -- ', len(allobjs)
        except Exception, msg:
            print Exception, msg
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllAssociatedMFDs(self, flow_domain, managers, return_corba_obj=0):
        if 'FlowDomain' not in managers:
            print(4, "No manager - FlowDomain")
            return []
        try:
            allobjs = []
            fd_name = flow_domain.name
            print '\n getAllAssociatedMFDs...', fd_name
            ems = managers['FlowDomain']
            counter = 1
            iterobjs, iterator = ems.getAllAssociatedMFDs(fd_name, 10)
            counter += 1
            allobjs.extend(iterobjs)
            if iterator:
                more = True
                while more:
                    print 'getting next 10...', counter
                    more, iterobjs = iterator.next_n(10)
                    counter += 1
                    allobjs.extend(iterobjs)
                    if not more:
                        break
        except Exception, msg:
            print Exception, msg
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllCPTPs(self, flow_domain, managers, return_corba_obj=0):
        if 'FlowDomain' not in managers:
            print(4, "No manager - FlowDomain")
            return []
        try:
            allobjs = []
            fd_name = flow_domain.name
            print '\n getAllCPTPs...', fd_name
            ems = managers['FlowDomain']
            counter = 1
            iterobjs, iterator = ems.getAllCPTPs(fd_name, flowDomain.CPTPR_ALL, FETCH_BULK)
            counter += 1
            allobjs.extend(iterobjs)
            if iterator:
                more = True
                while more:
                    print 'getting next 100...', counter
                    more, iterobjs = iterator.next_n(FETCH_BULK)
                    counter += 1
                    allobjs.extend(iterobjs)
                    if not more:
                        break
        except Exception, msg:
            print Exception, msg
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllTopologicalLinksOfFD(self, flow_domain, managers, return_corba_obj=0):
        if 'FlowDomain' not in managers:
            print(4, "No manager - FlowDomain")
            return []
        try:
            allobjs = []
            fd_name = flow_domain.name
            print '\n getAllTopologicalLinksOfFD...', fd_name
            ems = managers['FlowDomain']
            counter = 1
            iterobjs, iterator = ems.getAllTopologicalLinksOfFD(fd_name, 10)
            counter += 1
            allobjs.extend(iterobjs)
            if iterator:
                more = True
                while more:
                    print 'getting next 10...', counter
                    more, iterobjs = iterator.next_n(10)
                    counter += 1
                    allobjs.extend(iterobjs)
                    if not more:
                        break
        except Exception, msg:
            print Exception, msg
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs

    def getAllSFPsForNode(self, me_name, managers, return_corba_obj=0):
        print '\n\n getAllSFPsForNode...', me_name
        if 'PublishableMiscellaneous' not in managers:
            print(4, "No manager - PublishableMiscellaneous")
            return []
        print '\n\n able to get manager.. getAllSFPsForNode...', me_name
        allobjs = []
        try:
            ems = managers['PublishableMiscellaneous']
            iterobjs, iterator = ems.getAllSFPsForNode(me_name, FETCH_BULK, [])
            allobjs.extend(iterobjs)
            if iterator:
                more = True
                while more:
                    more, iterobjs = iterator.next_n(FETCH_BULK)
                    allobjs.extend(iterobjs)
                    if not more:
                        break
        except Exception, msg:
            print_exc()
        if not return_corba_obj:
            return [corbaObjToDict(obj) for obj in allobjs]
        else:
            return allobjs
