# CORBA Base Scanner File For TMF
# vijay - 07 June 2019
import json
import time
from os.path import dirname

import tmf
#from tmfutility import *



class BaseTMFScanner:
	managerMap = tmf.get_managers()

	def __init__(self):
		self.scan_vne = False

	def getEMSName(self, obj={}):
		return obj.get('nativeEMSName', '')

	def getEMSLabel(self, obj={}):
		return obj.get('userLabel', '')

	def getEMSType(self, obj={}):
		return obj.get('type', '')

	def getEMSVersion(self, obj={}):
		return obj.get('emsVersion', '')

	def getEMSOwner(self, obj={}):
		return obj.get('owner', '')

	def getDeviceVendor(self, obj={}):
		return ''

	def getDeviceModel(self, obj={}):
		return ''

	def getDeviceType(self, obj={}) :
		return ''

	def getDeviceContact(self, obj={}) :
		return ''

		
	def getOSName(self, obj={}) :
		return ''

	def getOSVersion(self, obj={}):
		return ''

	def getIPAddress(self, obj={}):
		return obj.get('name', {}).get('ManagedElement')

	def getPTPName(self, obj={}):
		return obj.get('nativeEMSName', '-NA-')

	def getPTPAlias(self, obj={}):
		return obj.get('userLabel', '')

	def getPTPType(self, obj={}):
		pType = obj.get('type', {})
		if pType and type(pType) == type({}):
			return ','.join(pType.keys())
		return str(pType)

	def getCTPType(self, obj={}):
		pType = obj.get('type', {})
		if pType and type(pType) == type({}):
			return ','.join(pType.keys())
		return str(pType)
		
	def getNameContext(self, emsname, version='3.5', vendor=''):
		return []

	def isVNE(self, obj):
		return False

	def getTrunkType(self, obj):
		return ''

	def scanNE(self, inst, ne, discovery_options = {}, dump_to_file = 0):
		scannerInst = self
		if not discovery_options:
			discovery_options = {'equipments': 1, 'ptp': 1, 'ctp': 0, 'topology': 0,
					'crossconnect': 0, 'snc': 0, 'sncroute': 0}
		if discovery_options.get('ctp') or discovery_options.get('topology') or discovery_options.get('snc'):
			discovery_options['ptp'] = 1
		if discovery_options.get('topology') or discovery_options.get('sncroute'):
			discovery_options['snc'] = 1 
		result = {}
		EQUIPMENTS = []
		PTPS = []
		CTP = {}
		SNC = {}
		TOPO = {}
		ROUTES = {}
		CROSS_CONNECTS = []
		outfolder = dirname + os.sep + inst.corba_ip
		ip = scannerInst.getIPAddress(ne)
		st = time.time()
		isValidIP = True
		try:	
			if not isValidIP:
				raise Exception("Invalid IP : %s" % str(ip))
			print "\n%s | IP : %s" % (time.ctime(), ip)
			identifier = ne.get('name', ne.get('identifier', {}))
			meName = make_managed_element_name(identifier)
			if discovery_options.get('equipments'):		
				EQUIPMENTS = execScanFunc(inst, scannerInst, 'getAllEquipment', (meName,))
				print '%s | EQUIPMENT Len >> %s' % (time.ctime(), len(EQUIPMENTS))
			if discovery_options.get('ptp'):
				PTPS = execScanFunc(inst, scannerInst, 'getAllPTPs', (meName,))
				print '%s | PTP Len >> %s' % (time.ctime(), len(PTPS))

			for ptp in PTPS:
				ptpidentifier = ptp.get('name')	
				ptpLabel = ptpidentifier.get('PTP', ptpidentifier.get('FTP'))
				ptpName = make_managed_element_name(ptpidentifier)
				# print ptpName
				if discovery_options.get('ctp'):
					ctps = execScanFunc(inst, scannerInst, 'getContainedPotentialTPs', (ptpName,))
					if ctps:
						CTP[ptpLabel] = ctps
				sncs = []
				if discovery_options.get('snc'):
					sncs = execScanFunc(inst, scannerInst, 'getAllSubnetworkConnectionsWithTP', (ptpName,))
				if sncs:
					print '	%s | SNC Len >> %s' % (time.ctime(), len(sncs))
					SNC[ptpLabel] = sncs
			routes_len , topo_len = 0, 0
			for ptpLabel, sncs in SNC.iteritems():
				for snc in sncs:
					sncidentifier = snc.get('name')
					sncName = make_managed_element_name(sncidentifier)
					sncLabel = sncidentifier.get('SubnetworkConnection')
					routes, topos = execScanFunc(inst, scannerInst, 'getRouteAndTopologicalLinks', (sncName, ))
					if routes:
						ROUTES[sncLabel] = routes
						routes_len += len(routes)
					if topos:
						TOPO[sncLabel] = topos
						topo_len += len(topos)
					"""
					if discovery_options.get('sncroute'):
						routes = execScanFunc(inst, scannerInst, 'getRoute', (sncName, ))
						if routes:
							ROUTES[sncLabel] = routes 
							print len(routes), "<< routes"
					if discovery_options.get('topology'):
						topos = execScanFunc(inst, scannerInst, 'getAllTopologicalLinks', (sncName,))					
						if topos:
							TOPO[sncLabel] = topos
							print len(topos), "<< topos"
					"""
			print '%s | Routes Len >> %s' % (time.ctime(), routes_len)
			print '%s | Topo Len >> %s' % (time.ctime(), topo_len)
			if discovery_options.get('crossconnect'):
				CROSS_CONNECTS = execScanFunc(inst, scannerInst, 'getAllCrossConnections', (meName,))
				print '%s | CROSS_CONNECTS Len >> %s' % (time.ctime(), len(CROSS_CONNECTS))
		except:
			print(4, "Exception in scanning individual NE", "General")
		finally:
			print "Elapsed -> %s\n" % str(time.time()-st)

		if EQUIPMENTS: result['EQUIPMENTS'] = EQUIPMENTS		
		if PTPS: result['PTPS'] = PTPS		
		if CTP:	result['CTP'] = CTP
		if SNC:	result['SNC'] = SNC
		if TOPO: result['TOPO'] = TOPO
		if ROUTES: result['ROUTES'] = ROUTES
		if CROSS_CONNECTS: result['CROSS_CONNECTS'] = CROSS_CONNECTS
		if dump_to_file and isValidIP:
			try:
				result['discovery_time'] = time.ctime()
				result['discovery_timestamp'] = time.time()
				with open(outfolder + os.sep + '%s.txt'%ip, 'w+') as f:
					f.write('%s' % json.dumps(result, indent=4))
			except:
				pass
		return result


	def getAllPTPsCTPsSNCsforME(self, managers, meName, tpLayerRateList=[], connectiontpLayerRateList=[], ctp=1, subnetwork=0, getroute = 0,return_corba_obj=0):
		if getroute:
			subnetwork = 1
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllPTPs(manager, meName, tpLayerRateList, connectiontpLayerRateList, return_corba_obj=1)
		print len(allobjs), "<< ptp len"
		if subnetwork:
			sub_manager = managers.get('MultiLayerSubnetwork')
			sub_mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		if ctp or subnetwork:
			for ptp in allobjs:
				print ptp.name
				if ctp:
					allCTPobjs = mngr_inst.getContainedPotentialTPs(manager, ptp.name, return_corba_obj=1)
					print "CTP", len(allCTPobjs)
					setattr(ptp, 'CTP', allCTPobjs)
				if subnetwork:
					allSNCobjs = sub_mngr_inst.getAllSubnetworkConnectionsWithTP(sub_manager, ptp.name, [], return_corba_obj=1)
					print "allSNCobjs", len(allSNCobjs)
					setattr(ptp, 'SNC', allSNCobjs)
					for snc in allSNCobjs:
						print snc.name
						SNCroutes  = sub_mngr_inst.getRoute(sub_manager, snc.name, return_corba_obj=1)
						print "SNCroutes", len(SNCroutes)

							
							
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs


	############################ EMS Manager ##############################

	def getEMSInfo(self, managers, return_corba_obj=0):	
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getEMS(manager, return_corba_obj)
		return allobjs

	def getAllTopLevelTopologicalLinks(self, managers, return_corba_obj=0):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllTopLevelTopologicalLinks(manager, return_corba_obj)
		return allobjs

	def getAllMLRAs(self, managers):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllMLRAs(manager)
		return allobjs

	def getAllMLSNPPLinks(self, managers):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllMLSNPPLinks(manager)
		return allobjs

	def getAllTopLevelSubnetworks(self, managers):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllTopLevelSubnetworks(manager)
		return allobjs

	def getAllTopLevelSubnetworkNames(self, managers):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllTopLevelSubnetworkNames(manager)
		return allobjs

	def getAllMLSNPPLinksWithTP(self, managers, tpName = []):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllMLSNPPLinksWithTP(manager, tpName)
		return allobjs

	def getAllMLSNPPLinksWithMLSNs(self, managers, mLRANames = []):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllMLSNPPLinksWithMLSNs(manager, mLRANames)
		return allobjs

	def getAllMLSNPPs(self, managers):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllMLSNPPs(manager)
		return allobjs

	def getAllMLSNPPsWithTP(self, managers, tpName = []):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllMLSNPPsWithTP(manager, tpName)
		return allobjs

	def getAllTopLevelTopologicalLinkNames(self, managers):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllTopLevelTopologicalLinkNames(manager)
		return allobjs

	def getTopLevelTopologicalLink(self, managers, topoLinkName = []):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getTopLevelTopologicalLink(manager, topoLinkName)
		return allobjs

	def getAllEMSAndMEActiveAlarms(self, managers, return_corba_obj=0):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllEMSAndMEActiveAlarms(manager, return_corba_obj=return_corba_obj)
		return allobjs

	def getAllEMSSystemActiveAlarms(self, managers):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllEMSSystemActiveAlarms(manager)
		return allobjs

	def getAllASAPs(self, managers):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.getAllASAPs(manager)
		return allobjs

	def acknowledgeAlarms(self, managers):
		if 'EMS' not in managers:
			print(4, "No manager - EMS")
			return []
		manager = managers.get('EMS')
		mngr_inst = self.managerMap.get('EMS')
		allobjs = mngr_inst.acknowledgeAlarms(manager)
		return allobjs

	def acknowledgeAlarms(self, managers, acknowledgeIDList = [], additionalInfo = [], return_corba_obj = 0):
		if 'EMS' not in managers:
			print(4, "No managers - EMS")
			return []
		manager = managers.get('EMS')
		managers_inst = self.managerMap.get('EMS')
		allobjs = managers_inst.acknowledgeAlarms(manager, acknowledgeIDList, additionalInfo)
		return allobjs  

	def unacknowledgeAlarms(self, managers, unacknowledgeIDList = [], additionalInfo = [], return_corba_obj = 0):
		if 'EMS' not in managers:
			print(4, "No managers - EMS")
			return []
		manager = managers.get('EMS')
		managers_inst = self.managerMap.get('EMS')
		allobjs = managers_inst.acknowledgeAlarms(manager, unacknowledgeIDList, additionalInfo)
		return allobjs   

	def getAllEMSAndMEUnacknowledgedActiveAlarms(self, managers, excludeProbCauseList = [], excludeSeverityList = [], return_corba_obj = 0):
		if 'EMS' not in managers:
			print(4, "No managers - EMS")
			return []
		manager = managers.get('EMS')
		managers_inst = self.managerMap.get('EMS')
		allobjs = managers_inst.getAllEMSAndMEUnacknowledgedActiveAlarms(manager, excludeProbCauseList, excludeSeverityList)
		return allobjs 

	def getAllEMSSystemUnacknowledgedActiveAlarms(self, managers, excludeSeverityList = [], return_corba_obj = 0):
		if 'EMS' not in managers:
			print(4, "No managers - EMS")
			return []
		manager = managers.get('EMS')
		managers_inst = self.managerMap.get('EMS')
		allobjs = managers_inst.getAllEMSSystemUnacknowledgedActiveAlarms(manager, excludeSeverityList)
		return allobjs 

	def getAllASAPNames(self, managers, return_corba_obj = 0):
		if 'EMS' not in managers:
			print(4, "No managers - EMS")
			return []
		manager = managers.get('EMS')
		managers_inst = self.managerMap.get('EMS')
		allobjs = managers_inst.getAllASAPNames(manager)
		return allobjs   

	def getASAP(self, managers, aSAPName = [], return_corba_obj = 0):
		if 'EMS' not in managers:
			print(4, "No managers - EMS")
			return []
		manager = managers.get('EMS')
		managers_inst = self.managerMap.get('EMS')
		allobjs = managers_inst.getASAP(manager, aSAPName)
		return allobjs    

	def getASAPbyResource(self, managers, resourceName = [], layerRateList = [], return_corba_obj = 0):
		if 'EMS' not in managers:
			print(4, "No managers - EMS")
			return []
		manager = managers.get('EMS')
		managers_inst = self.managerMap.get('EMS')
		allobjs = managers_inst.getASAPbyResource(manager, resourceName, layerRateList)
		return allobjs  

	def getASAPAssociatedResourceNames(self, managers, aSAPName = [], return_corba_obj = 0):
		if 'EMS' not in managers:
			print(4, "No managers - EMS")
			return []
		manager = managers.get('EMS')
		managers_inst = self.managerMap.get('EMS')
		allobjs = managers_inst.getASAPAssociatedResourceNames(manager, aSAPName)
		return allobjs   		  

	def getAllMLSNPPLinksWithTNAs(self, managers, tNAList = [], return_corba_obj = 0):
		if 'EMS' not in managers:
			print(4, "No managers - EMS")
			return []
		manager = managers.get('EMS')
		managers_inst = self.managerMap.get('EMS')
		allobjs = managers_inst.getAllMLSNPPLinksWithTNAs(manager, tNAList)
		return allobjs     

	def getAllMLSNPPsWithTNA(self, managers, tNAList = [], return_corba_obj = 0):
		if 'EMS' not in managers:
			print(4, "No managers - EMS")
			return []
		manager = managers.get('EMS')
		managers_inst = self.managerMap.get('EMS')
		allobjs = managers_inst.getAllMLSNPPsWithTNA(manager, tNAList)
		return allobjs

	#======= Managed Element Functions ======

	def getAllManagedElements(self, managers, return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllManagedElements(manager, return_corba_obj)
		return allobjs

	def getAllManagedElementNames(self, managers, return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllManagedElementNames(manager)
		return allobjs

	def getContainingSubnetworkNames(self, managers, allNesNames=[], return_corba_obj=0):	
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getContainingSubnetworkNames(manager,allNesNames)
		return allobjs

	def getAllPTPs(self, managers, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllPTPs(manager, meName, tpLayerRateList, connectiontpLayerRateList)
		return allobjs

	def getAllPTPsWithoutFTPs(self, managers, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllPTPsWithoutFTPs(manager, meName, tpLayerRateList, connectiontpLayerRateList)
		return allobjs

	def getAllFTPs(self, managers, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllFTPs(manager, meName, tpLayerRateList, connectiontpLayerRateList)
		return allobjs

	def getAllPTPNames(self, managers, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllPTPNames(manager, meName, tpLayerRateList, connectiontpLayerRateList)
		return allobjs

	def getAllPTPNamesWithoutFTPs(self, managers, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllPTPNamesWithoutFTPs(manager, meName, tpLayerRateList, connectiontpLayerRateList)
		return allobjs

	def getAllFTPNames(self, managers, meName, tpLayerRateList=[], connectiontpLayerRateList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers['ManagedElement']
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllFTPNames(manager, meName, tpLayerRateList, connectiontpLayerRateList)
		return allobjs

	def getTP(self,managers,tpName,return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getTP(manager,tpName)
		return allobjs

	def getManagedElement(self,managers, meName, return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []	
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getManagedElement(manager,meName)
		return allobjs

	def getContainedPotentialTPs(self, managers, tpName, tpLayerRateList=[], return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getContainedPotentialTPs(manager, tpName, tpLayerRateList)
		return allobjs

	def getContainedPotentialTPNames(self, managers, tpName, tpLayerRateList=[], return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getContainedPotentialTPNames(manager, tpName, tpLayerRateList)
		return allobjs

	def getContainedInUseTPs(self, managers, tpName, tpLayerRateList=[], return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getContainedInUseTPs(manager, tpName, tpLayerRateList)
		return allobjs

	def getContainedInUseTPNames(self, managers, tpName, tpLayerRateList=[], return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getContainedInUseTPNames(manager,tpName, tpLayerRateList)
		return allobjs

	def getContainedCurrentTPs(self, managers, tpName, tpLayerRateList=[], return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getContainedCurrentTPs(manager, tpName, tpLayerRateList)
		return allobjs

	def getContainedCurrentTPNames(self, managers, tpName, tpLayerRateList=[], return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getContainedCurrentTPNames(manager, tpName, tpLayerRateList)
		return allobjs

	def getContainingTPs(self,managers,tpName,return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getContainingTPs(manager,tpName)
		return allobjs

	def getContainingTPNames(self,manager,tpName,return_corba_obj=0):
		if 'ManagedElement' not in manager:
			print(4, "No manager - ManagedElement")
			return []
		manager = manager.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getContainingTPNames(manager, tpName)
		return allobjs

	def getAllActiveAlarms(self, managers, meName, excludeProbCauseList=[],excludeSeverityList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllActiveAlarms(manager, meName, excludeProbCauseList, excludeSeverityList, return_corba_obj)
		return allobjs

	def getAllUnacknowledgedActiveAlarms(self, managers, meName, excludeProbCauseList=[],excludeSeverityList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllUnacknowledgedActiveAlarms(manager,meName, excludeProbCauseList, excludeSeverityList)
		return allobjs

	def getAllCrossConnections(self, managers, tpName, tpLayerRateList=[], return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllCrossConnections(manager, tpName, tpLayerRateList, return_corba_obj)
		return allobjs

	def createGTP(self, managers, userLabel,forceUniqueness=True,owner='',listOfTPs=[],initialCTPname=[],gtpEffort=[],additionalCreationInfo=[], return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.createGTP(manager, userLabel, forceUniqueness, owner, listOfTPs, initialCTPname, gtpEffort, additionalCreationInfo)
		return allobjs

	def getGTP(self, managers, gtpName=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getGTP(manager, gtpName)
		return allobjs

	def getAllGTPs(self, managers, meName, tpLayerRateList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllGTPs(manager, meName, tpLayerRateList)
		return allobjs

	def getAllGTPNames(self, managers, meName, tpLayerRateList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllGTPNames(manager, meName, tpLayerRateList)
		return allobjs

	def getContainingGTP(self, managers, ctpName=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getContainingGTP(manager, ctpName)
		return allobjs

	def verifyTMDAssignment(self, managers,tpName,direction=[]):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.verifyTMDAssignment(manager, tpName, direction)
		return allobjs

	def getAllFixedCrossConnections(self, managers, meName, connectiontpLayerRateList=[],return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllFixedCrossConnections(manager, meName, connectiontpLayerRateList)
		return allobjs

	def getPotentialFixedCCs(self, managers,inputTP):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getPotentialFixedCCs(manager,inputTP)
		return allobjs

	def getAllPTPsCTPs(self, managers, tpName, tpLayerRateList=[], connectiontpLayerRateList=[], ctp=1,return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getAllPTPsCTPsforME(manager,tpName, tpLayerRateList, connectiontpLayerRateList ,ctp)
		return allobjs

	def getCTPsforPTP(self, managers, ptp_name, all_ctps = 1, return_corba_obj=0):
		if 'ManagedElement' not in managers:
			print(4, "No manager - ManagedElement")
			return []
		manager = managers.get('ManagedElement')
		mngr_inst = self.managerMap.get('ManagedElement')
		allobjs = mngr_inst.getCTPsforPTP(manager, ptp_name, all_ctps)
		return allobjs

	#======= Equipment Inventory ========

	def getContainedEquipment(self, managers, eqholder, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getContainedEquipment(manager,eqholder)
		return allobjs

	def getEquipment(self, managers, eqholder, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getAllManagedElements(manager, eqholder)
		return allobjs

	def getAllEquipment(self, managers, meName, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getAllEquipment(manager, meName, return_corba_obj)
		return allobjs

	def getAllEquipmentNames(self, managers, meName, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getAllEquipmentNames(manager, meName)
		return allobjs

	def getAllSupportedPTPs(self, managers, meName, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getAllSupportedPTPs(manager,meName)
		return allobjs

	def getAllSupportedPTPNames(self, managers, meName, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getAllSupportedPTPNames(manager, meName)
		return allobjs

	def getAllSupportingEquipment(self, managers, meName, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getAllSupportingEquipment(manager, meName)
		return allobjs

	def getAllSupportingEquipmentNames(self, managers, meName, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getAllSupportingEquipmentNames(manager, meName)
		return allobjs

	def getSupportingEquipment(self, managers, meName, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getSupportingEquipment(manager, meName)
		return allobjs

	def getSupportingEquipmentNames(self, managers, meName, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getSupportingEquipmentNames(manager, meName)
		return allobjs

	def getSupportedEquipment(self, managers, meName, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getSupportedEquipment(manager, meName)
		return allobjs

	def getSupportedEquipmentNames(self, managers, meName, return_corba_obj=0):
		if 'EquipmentInventory' not in managers:
			print(4, "No manager - EquipmentInventory")
			return []
		manager = managers.get('EquipmentInventory')
		mngr_inst = self.managerMap.get('EquipmentInventory')
		allobjs = mngr_inst.getSupportedEquipmentNames(manager, meName)
		return allobjs

	############MultiLayerSubnetwork#############

	def getTopologicalLink(self, managers, topoLinkName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getTopologicalLink(manager, topoLinkName)
		return allobjs

	def getMultiLayerSubnetwork(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getMultiLayerSubnetwork(manager, subnetName)
		return allobjs

	def getAllTopologicalLinks(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllTopologicalLinks(manager, subnetName)
		return allobjs 

	def getAllTopologicalLinkNames(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllTopologicalLinkNames(manager, subnetName)
		return allobjs  

	def getAllEdgePoints(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllEdgePoints(manager, subnetName)
		return allobjs

	def getAllEdgePointNames(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllEdgePointNames(manager, subnetName)
		return allobjs

	def getAllSubnetworkConnections(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllSubnetworkConnections(manager, subnetName)
		return allobjs

	def getAllSubnetworkConnectionNames(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllSubnetworkConnectionNames(manager, subnetName)
		return allobjs

	def getAllFixedSubnetworkConnections(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllFixedSubnetworkConnections(manager, subnetName)
		return allobjs
		
	def getAllFixedSubnetworkConnectionNames(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllFixedSubnetworkConnectionNames(manager, subnetName)
		return allobjs

	def getAllFixedSubnetworkConnectionsWithTP(self, managers, tpName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllFixedSubnetworkConnectionsWithTP(manager, tpName)
		return allobjs

	def getAllFixedSubnetworkConnectionNamesWithTP(self, managers, tpName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllFixedSubnetworkConnectionNamesWithTP(manager, tpName)
		return allobjs

	def getBackupRoutes(self, managers, sncName = [], routeId = ''):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getBackupRoutes(manager, sncName, routeId)
		return allobjs

	def getIntendedRoute(self, managers, sncName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getIntendedRoute(manager, sncName)
		return allobjs

	def getAllSubordinateMLSNs(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs, additionalInfo = mngr_inst.getAllSubordinateMLSNs(manager, subnetName)
		return allobjs, additionalInfo

	def getTPPool(self, managers, tPPoolName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs, numberOfMembers, numberOfIdleMembers, descriptionOfUse = mngr_inst.getTPPool(manager, tPPoolName)
		return allobjs, numberOfMembers, numberOfIdleMembers, descriptionOfUse

	def getAllSubordinateRAidsWithConnection(self, managers, subnetName = [], connection = [], routeType = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllSubordinateRAidsWithConnection(manager, subnetName, connection, routeType)
		return allobjs

	def getMLSNPPLink(self, managers, mLSNPPLinkName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getMLSNPPLink(manager, mLSNPPLinkName)
		return allobjs

	def getAllMLSNPPLinks(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllMLSNPPLinks(manager, subnetName)
		return allobjs

	def getAllInternalMLSNPPLinks(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllInternalMLSNPPLinks(manager, subnetName)
		return allobjs

	def getAllEdgeMLSNPPLinks(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllEdgeMLSNPPLinks(manager, subnetName)
		return allobjs

	def getAllMLSNPPs(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllMLSNPPs(manager, subnetName)
		return allobjs

	def getAllCallsAndTopLevelConnections(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllCallsAndTopLevelConnections(manager, subnetName)
		return allobjs

	def getAllCallsAndTopLevelConnectionsAndSNCs(self, managers, subnetName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllCallsAndTopLevelConnectionsAndSNCs(manager, subnetName)
		return allobjs

	def getAllCallsAndTopLevelConnectionsWithME(self, managers, subnetName = [], meName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllCallsAndTopLevelConnectionsWithME(manager, subnetName, meName)
		return allobjs

	def getAllCallsAndTopLevelConnectionsAndSNCsWithME(self, managers, subnetName = [], meName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllCallsAndTopLevelConnectionsAndSNCsWithME(manager, subnetName, meName)
		return allobjs

	def getAllCallsAndTopLevelConnectionsAndSNCsWithTP(self, managers, subnetName = [], tpName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllCallsAndTopLevelConnectionsAndSNCsWithTP(manager, subnetName, tpName)
		return allobjs

	def getAllCallIdsWithTP(self, managers, sNPPOrTNAName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllCallIdsWithTP(manager, sNPPOrTNAName)
		return allobjs

	def getAllCallIdsWithSNPPOrTNAName(self, managers, sNPPOrTNAName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllCallIdsWithSNPPOrTNAName(manager, sNPPOrTNAName)
		return allobjs

	def getCallAndTopLevelConnectionsAndSNCs(self, managers, callName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getCallAndTopLevelConnectionsAndSNCs(manager, callName)
		return allobjs

	def getCallAndTopLevelConnections(self, managers, callName = [], callId = ''):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getCallAndTopLevelConnections(manager, callName, callId)
		return allobjs

	def getCall(self, managers, callName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getCall(manager, callName)
		return allobjs

	def getConnectionsAndRouteDetails(self, managers, callID='', mLRAName=[],sNPOrSNPPID='', routeType=[]):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getConnectionsAndRouteDetails(manager, callID, mLRAName,sNPOrSNPPID, routeType)
		return allobjs

	def getAllTPPoolNames(self, managers, subnetworkName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllTPPoolNames(manager, subnetworkName)
		return allobjs

	def getAllTPPools(self, managers, subnetworkName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllTPPools(manager, subnetworkName)
		return allobjs

	def getSNCsByUserLabel(self, managers, userLabel = ''):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getSNCsByUserLabel(manager, userLabel)
		return allobjs

	def getSNC(self, managers, sncName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getSNC(manager, sncName)
		return allobjs

	def getRouteAndTopologicalLinks(self, managers, sncName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getRouteAndTopologicalLinks(manager, sncName)
		return allobjs

	def getRoute(self, managers, sncName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getRoute(manager, sncName)
		return allobjs

	def getAllSubnetworkConnectionNamesWithTP(self, managers, tpName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllSubnetworkConnectionNamesWithTP(manager, tpName)
		return allobjs

	def getAllSubnetworkConnectionsWithTP(self, managers, tpName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAllSubnetworkConnectionsWithTP(manager, tpName)
		return allobjs

	def getTPGroupingRelationships(self, managers, tpName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getTPGroupingRelationships(manager, tpName)
		return allobjs

	def getAssociatedTP(self, managers, tpName = []):
		if 'MultiLayerSubnetwork' not in managers:
			print(4, "No manager - MultiLayerSubnetwork")
			return []
		manager = managers.get('MultiLayerSubnetwork')
		mngr_inst = self.managerMap.get('MultiLayerSubnetwork')
		allobjs = mngr_inst.getAssociatedTP(manager, tpName)
		return allobjs

	#========== Flow Domain =========

	def getAllFlowDomains(self, managers, return_corba_obj = 0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getAllFlowDomains(manager)
		return allobjs

	def getFlowDomainsByUserLabel(self, managers, userLabel = '', return_corba_obj = 0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getFlowDomainsByUserLabel(manager, userLabel)
		return allobjs

	def getFlowDomain(self, managers, fdName = [], return_corba_obj = 0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getFlowDomain(manager, fdName)
		return allobjs

	def getAssociatingFD(self, managers, mfdName = [], return_corba_obj = 0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getAssociatingFD(manager, mfdName)
		return allobjs

	def getTransmissionParams(self, managers, name = [], filter_list = [], return_corba_obj = 0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getTransmissionParams(manager, name, filter_list)
		return allobjs

	def getAllAssociatedMFDs(self, managers, tmdOrFdName = [], return_corba_obj = 0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers['FlowDomain']
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getAllAssociatedMFDs(manager, tmdOrFdName)
		return allobjs

	def getAllSupportedMFDs(self, managers, holderName = [], return_corba_obj = 0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getAllSupportedMFDs(manager, holderName)
		return allobjs	

	def getMFD(self, managers, mfdName = [], return_corba_obj = 0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getMFD(manager, mfdName)
		return allobjs

	def getAssigningMFD(self, managers, cptpName = [], return_corba_obj = 0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getAssigningMFD(manager, cptpName)
		return allobjs

	def getAllCPTPs(self, managers, fdName=[],cptpRole=[],return_corba_obj=0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getAllCPTPs(manager, fdName, cptpRole)
		return allobjs

	def getAllAssignedCPTPs(self, managers, mfdName = [], return_corba_obj=0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getAllAssignedCPTPs(manager, mfdName)
		return allobjs

	def getAllAssignableCPTPs(self, managers, mfdName = [], return_corba_obj=0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getAllAssignableCPTPs(manager, mfdName)
		return allobjs

	def getAllFDFrs(self, managers, fdName = [], connectivityRateList = [], return_corba_obj=0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getAllFDFrs(manager, fdName, connectivityRateList)
		return allobjs

	def getFDFrsWithTP(self, managers, cptpName = [], return_corba_obj=0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getFDFrsWithTP(manager, cptpName)
		return allobjs

	def getFDFrsByUserLabel(self, managers, userLabel='', return_corba_obj=0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getFDFrsByUserLabel(manager, userLabel)
		return allobjs

	def getFDFr(self, managers,fdfrName=[], return_corba_obj=0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getFDFr(manager, fdfrName)
		return allobjs

	def getAllTopologicalLinksOfFD(self, managers, flowDomainName = [],return_corba_obj=0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getAllTopologicalLinksOfFD(manager, flowDomainName)
		return allobjs

	def getFDFrRoute(self, managers,fdfrName=[], return_corba_obj=0):
		if 'FlowDomain' not in managers:
			print(4, "No manager - FlowDomain")
			return []
		manager = managers.get('FlowDomain')
		mngr_inst = self.managerMap.get('FlowDomain')
		allobjs = mngr_inst.getFDFrRoute(manager, fdfrName)
		return allobjs

	#===================== protection ==========================

	def getAllProtectionGroups(self, managers, meName, return_corba_obj=0):
		if 'Protection' not in managers:
			print(4, "No manager - Protection")
			return []
		manager = managers['Protection']
		allobjs = []
		try:
			allobjs, iterator = manager.getAllProtectionGroups(meName, FETCH_BULK)
			if iterator:
				more = True
				while more:
					more, iterobjs = iterator.next_n(FETCH_BULK)
					allobjs.extend(iterobjs)
					if not more:
						break
		except Exception, msg:
			print_exc()
		if not return_corba_obj:
			return [corbaObjToDict(obj) for obj in allobjs]
		else:
			return allobjs

	def getAllEMSGroups(self, managers, meName = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.getAllEMSGroups(manager, meName)
		return allobjs

	def getAllEEMSGroups(self, managers, meName = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.getAllEEMSGroups(manager, meName)
		return allobjs

	def getEMSGroup(self, managers, pgName = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.getEMSGroup(manager, pgName)
		return allobjs

	def getEEMSGroup(self, managers, ePGPname = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.getEEMSGroup(manager, ePGPname)
		return allobjs

	def getAllNUTTPNames(self, managers, pgName = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.getAllEMSGroups(manager, pgName)
		return allobjs

	def getAllPreemptibleTPNames(self, managers, pgName = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.getAllEMSGroups(manager, pgName)
		return allobjs

	def getAllProtectedTPNames(self, managers, pgName = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.getAllProtectedTPNames(manager, pgName)
		return allobjs		

	def retrieveSwitchData(self, managers, reliableSinkCtpOrGroupName = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.retrieveSwitchData(manager, reliableSinkCtpOrGroupName)
		return allobjs	

	def retrieveESwitchData(self, managers, ePGPname = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.retrieveESwitchData(manager, ePGPname)
		return allobjs		

	def performEMSCommand(self, managers, EMSCommand = [], reliableSinkCtpOrGroupName = [], fromTp = [], toTp = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.performEMSCommand(manager, EMSCommand, reliableSinkCtpOrGroupName, fromTp, toTp)
		return allobjs	

	def getContainingPGNames(self, managers, pTPName = [], return_corba_obj = 0):
		if 'Protection' not in managers:
			print(4, "No managers - Protection")
			return []
		manager = managers.get('Protection')
		managers_inst = self.managerMap.get('Protection')
		allobjs = managers_inst.getContainingPGNames(manager, pTPName)
		return allobjs

	# ============ TCProfile =============

	def getAllTCProfiles(self, managers, return_corba_obj=0):
		if 'TCProfile' not in managers:
			print(4, "No manager - TCProfile")
			return []
		manager = managers.get('TCProfile')
		mngr_inst = self.managerMap.get('TCProfile')
		allobjs = mngr_inst.getAllTCProfiles(manager)
		return allobjs

	def getTCProfile(self, managers,tcProfileName=[], return_corba_obj=0):
		if 'TCProfile' not in managers:
			print(4, "No manager - TCProfile")
			return []
		manager = managers.get('TCProfile')
		mngr_inst = self.managerMap.get('TCProfile')
		allobjs = mngr_inst.getTCProfile(manager, tcProfileName)
		return allobjs

	def getTCProfileAssociatedTPs(self, managers, tcProfileName=[],return_corba_obj=0):
		if 'TCProfile' not in managers:
			print(4, "No manager - TCProfile")
			return []
		manager = managers.get('TCProfile')
		mngr_inst = self.managerMap.get('TCProfile')
		allobjs = mngr_inst.getTCProfileAssociatedTPs(manager, tcProfileName)
		return allobjs

	#====== Performance Management =========

	def getMEPMcapabilities(self, managers, meName, tpLayerRateList=[], return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getMEPMcapabilities(manager, meName, tpLayerRateList)
		return allobjs

	def disablePMData(self, managers,pmTPSelectList=[], return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.disablePMData(manager, pmTPSelectList)
		return allobjs

	def enablePMData(self, managers,pmTPSelectList=[], return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.enablePMData(manager, pmTPSelectList)
		return allobjs

	def clearPMData(self, managers,pmTPSelectList=[], return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.clearPMData(manager, pmTPSelectList)
		return allobjs

	def getHoldingTime(self, managers):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getHoldingTime(manager)
		return allobjs

	def getTCATPParameter(self, managers,tpName=[],tpLayerRateList=[], granularity=[],return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getTCATPParameter(manager, tpName, granularity)
		return allobjs

	def getAllCurrentPMData (self, managers, pmTPSelectList=[], pmParameters=[], return_corba_obj = 0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getAllCurrentPMData(manager, pmTPSelectList, pmParameters)
		return allobjs

	def enableTCA(self, managers,pmTPSelectList=[], return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.enableTCA(manager, pmTPSelectList)
		return allobjs

	def disableTCA(self, managers,pmTPSelectList=[], return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.disableTCA(manager, pmTPSelectList)
		return allobjs

	def getProfileAssociatedTPs(self, managers, profileName=[],return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getProfileAssociatedTPs(manager, profileName)
		return allobjs

	def getTCAParameterProfile(self, managers,tcaParameterProfileName=[], return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getTCAParameterProfile(manager, tcaParameterProfileName)
		return allobjs

	def getAllTCAParameterProfileNames(self, managers, meName,return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getAllTCAParameterProfileNames(manager, meName)
		return allobjs

	def getAllPMPs(self, managers, meName,return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getAllPMPs(manager, meName)
		return allobjs

	def getAllPMPNames(self, managers, meName,return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getAllPMPNames(manager, meName)
		return allobjs

	def getAllTCAParameterProfiles(self, managers, meName,return_corba_obj=0):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []
		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getAllTCAParameterProfiles(manager, meName)
		return allobjs

	def getHistoryPMData(self, managers,destination=[], userName='', password='', pmTPSelectList=[], pmParameters=[], startTime=[], endTime=[], forceUpload=True):
		if 'PerformanceManagement' not in managers:
			print(4, "No manager - PerformanceManagement")
			return []

		manager = managers.get('PerformanceManagement')
		mngr_inst = self.managerMap.get('PerformanceManagement')
		allobjs = mngr_inst.getHistoryPMData(manager, destination,userName,password,pmTPSelectList,pmParameters, startTime, endTime, forceUpload)
		return allobjs
