import json

from flask import Flask, escape, request
from flask import render_template
from tmftester import *
from json2html import *
from flask import Markup

app = Flask(__name__)


def html_table(tmfobj):
    return Markup(json2html.convert(json.dumps(tmfobj), table_attributes="class=\"table-bordered table-hover\""))

@app.route('/')
def home():
    return render_template("base.html")


@app.route('/getemsinfo')
def ems():
    corbaobj, emsinfo = get_ems_info()
    return render_template("dataview.html", data=html_table(emsinfo), corbaobj=corbaobj)


@app.route('/getallalarms')
def alarms():
    corbaobj, alarms = get_all_alarms()
    return render_template("dataview.html", data=html_table(alarms), corbaobj=corbaobj)


@app.route('/getallne')
def nes():
    corbaobj, nes = get_all_ne()
    return render_template("dataview.html", data=html_table(nes), corbaobj=corbaobj)

@app.route('/getalltls')
def getalltls():
    corbaobj, tls = get_all_tls()
    return render_template("dataview.html", data=html_table(tls), corbaobj=corbaobj)

@app.route('/nedata', methods=["GET","POST"])
def nedata():
    if request.method == "POST":
        neip = request.form["nodeip"]
        opt = request.form["opt"]
        corbaobj = nedata = None

        if opt == "alarms":
            corbaobj, nedata = get_all_ne_alarms(str(neip))
        elif opt == "equip":
            corbaobj, nedata = get_all_ne_equipment(str(neip))
        elif opt == "snc":
            corbaobj, nedata = get_all_ne_SNC(str(neip))
        else:
            pass
        return render_template("neview.html", data=html_table(nedata), corbaobj=corbaobj)
    else:
        return render_template("neview.html")


@app.route("/createsnc", methods=["GET", "POST"])
def createsnc():
    if request.method == "POST":
        sncname = str(request.form["sncname"])
        nodeip = str(request.form["nodeip"])
        sptp = str(request.form["sptp"])
        sctp = str(request.form["sctp"])
        dptp = str(request.form["dptp"])
        dctp = str(request.form["dctp"])

        onodeip = str(request.form["onodeip"])
        osptp = str(request.form["osptp"])
        osctp = str(request.form["osctp"])
        odptp = str(request.form["odptp"])
        odctp = str(request.form["odctp"])

        rate = int(request.form["rate"])
        if 'oduflex' in dctp or 'oduflex' in odctp:
            rate = 10100 + rate


        corbaobj, data = create_snc(sncname, nodeip, sptp, sctp, dptp, dctp, rate)
        time.sleep(1)
        corbaobj1, data1 = create_snc(sncname, onodeip, osptp, osctp, odptp, odctp, rate)

        return render_template("createsnc.html", data=html_table(data), corbaobj=corbaobj, data1=html_table(data1), corbaobj1=corbaobj1)
    else:
        return render_template("createsnc.html")

@app.route("/deletesnc", methods=["GET", "POST"])
def deletesnc():
    if request.method == "POST":
        sncname = str(request.form["sncname"])
        nodeip = str(request.form["nodeip"])
        corbaobj, data = delete_snc(sncname, nodeip)

        return render_template("deletesnc.html", data=html_table(data), corbaobj=corbaobj)
    else:
        return render_template("deletesnc.html")


@app.route("/modifysnc", methods=["GET", "POST"])
def modifysnc():
    if request.method == "POST":
        sncname = str(request.form["sncname"])
        nodeip = str(request.form["nodeip"])
        sptp = str(request.form["sptp"])
        sctp = str(request.form["sctp"])
        dptp = str(request.form["dptp"])
        dctp = str(request.form["dctp"])

        osncname = str(request.form["osncname"])
        onodeip = str(request.form["onodeip"])
        osptp = str(request.form["osptp"])
        osctp = str(request.form["osctp"])
        odptp = str(request.form["odptp"])
        odctp = str(request.form["odctp"])

        rate = int(request.form["rate"])
        if 'oduflex' in dctp or 'oduflex' in odctp:
            rate = 10100 + rate

        corbaobj, data = modify_snc(sncname, nodeip, sptp, sctp, dptp, dctp, rate)
        corbaobj1, data1 = modify_snc(osncname, onodeip, osptp, osctp, odptp, odctp, rate)

        return render_template("modifysnc.html", data=html_table(data), corbaobj=corbaobj, data1=html_table(data1), corbaobj1=corbaobj1)
    else:
        return render_template("modifysnc.html")


@app.route("/notify", methods=["GET", "POST"])
def notification():
    return render_template("tmf_notification.log")


if __name__ == '__main__':
    app.run("0.0.0.0", 81, debug=True)
