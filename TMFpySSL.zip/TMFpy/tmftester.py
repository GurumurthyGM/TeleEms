import json


from tmf.idlc_tmf_v35.subnetworkConnection_idl import SNCCreateData_T, _0_subnetworkConnection

from tmf.apiinterface.tejasinterface import TEJASCorbaInterface
from tmf.idlc_tmf_v35 import CosNaming, globaldefs
from tmf.tmfutility import *
from tmf.managers.MultiLayerSubnetwork_Mgr import MultiLayerSubnetwork



emsname = "EMS_1"
ip = "192.168.228.23"
user, pw = 'administrator', 'tejas;Allowed'

tejems = TEJASCorbaInterface()
name_context = tejems.getNameContext(emsname)
# name_context = [
#     CosNaming.NameComponent("TMF_MTNM", "Class"),
#     CosNaming.NameComponent("TejasNetworks", "Vendor"),
#     CosNaming.NameComponent("TejasNetworks/%s" % emsname, "EmsInstance"),
#     CosNaming.NameComponent("3.5", "Version"),
#     CosNaming.NameComponent("TejasNetworks/%s" % emsname, "EmsSessionFactory_I")
# ]

nmslogin = CorbaInterface(ip, 20900, user, pw, name_context=name_context)



def jprint(data):
    print(json.dumps(data, indent=3))


def get_ems_info():
    nmslogin.connect()
    try:
        supported_mngrs = nmslogin.getManagers()
        #print(supported_mngrs)
        emsinfo = tejems.getEMSInfo(supported_mngrs, return_corba_obj=1)
        print(emsinfo)
        return emsinfo, corbaObjToDict(emsinfo)
    finally:
        nmslogin.endSession()


def get_all_ne():
    nmslogin.connect()
    try:
        supported_mngrs = nmslogin.getManagers()
        # print(supported_mngrs)
        nes = tejems.getAllManagedElements(supported_mngrs, return_corba_obj=1)
        print(nes)
        return nes, corbaObjToDict(nes)
    finally:
        nmslogin.endSession()


def get_all_alarms():
    nmslogin.connect()
    try:
        supported_mngrs = nmslogin.getManagers()
        # print(supported_mngrs)
        alarms = tejems.getAllEMSAndMEActiveAlarms(supported_mngrs, return_corba_obj=1)
        print(alarms)
        return alarms, corbaObjToDict(alarms)
    finally:
        nmslogin.endSession()


def get_all_tls():
    nmslogin.connect()
    try:
        supported_mngrs = nmslogin.getManagers()
        # print(supported_mngrs)
        tls = tejems.getAllTopLevelTopologicalLinks(supported_mngrs, return_corba_obj=1)
        print(tls)
        return tls, corbaObjToDict(tls)
    finally:
        nmslogin.endSession()



def get_all_ne_alarms(neip):
    nmslogin.connect()
    try:
        supported_mngrs = nmslogin.getManagers()
        # print(supported_mngrs)
        mename = make_managed_element_name({'EMS': emsname, "ManagedElement": neip})
        print(mename)
        ne_alarms = tejems.getAllActiveAlarms(supported_mngrs, mename, return_corba_obj=1)
        print(ne_alarms)
        return ne_alarms, corbaObjToDict(ne_alarms)
    finally:
        nmslogin.endSession()


def get_all_ne_equipment(neip):
    nmslogin.connect()
    try:

        supported_mngrs = nmslogin.getManagers()
        # print(supported_mngrs)
        mename = make_managed_element_name({'EMS': emsname, "ManagedElement": neip})
        print(mename)
        ne_eqpmnt = tejems.getAllEquipment(supported_mngrs, mename, return_corba_obj=1)
        print(ne_eqpmnt)
        return ne_eqpmnt, corbaObjToDict(ne_eqpmnt)
    finally:
        nmslogin.endSession()


def get_all_ne_SNC(neip):

    nmslogin.connect()
    try:
        supported_mngrs = nmslogin.getManagers()
        # print(supported_mngrs)
        mlsn_mngr = supported_mngrs.get("MultiLayerSubnetwork")
        mlsn = MultiLayerSubnetwork()
        subnetwork_name = make_managed_element_name({'EMS': emsname, "MultiLayerSubnetwork": neip})
        print(subnetwork_name)
        ne_snc = mlsn.getAllSubnetworkConnections(mlsn_mngr, subnetwork_name, return_corba_obj=1)
        print(ne_snc)
        return ne_snc, corbaObjToDict(ne_snc)
    finally:
        nmslogin.endSession()


def create_snc(userLabel, neip, sptp, sctp, dptp, dctp, rate):

    nmslogin.connect()
    forceUniqueness = False
    owner = "Tejas"
    direction = globaldefs.CD_BI
    staticProtectionLevel = _0_subnetworkConnection.UNPROTECTED
    protectionEffort = _0_subnetworkConnection.EFFORT_SAME
    rerouteAllowed = _0_subnetworkConnection.RR_NA
    networkRouted = _0_subnetworkConnection.NR_NA
    sncType = _0_subnetworkConnection.ST_SIMPLE
    layerRate = rate
    ccInclusions = []
    neTpInclusions = [[]]
    fullRoute = False
    neTpSncExclusions = [[]]

    aEnd = [(globaldefs.NameAndStringValue_T("EMS", emsname), globaldefs.NameAndStringValue_T("ManagedElement", neip), globaldefs.NameAndStringValue_T("PTP", sptp), globaldefs.NameAndStringValue_T("CTP", sctp))]
    zEnd = [[globaldefs.NameAndStringValue_T("EMS", emsname), globaldefs.NameAndStringValue_T("ManagedElement", neip), globaldefs.NameAndStringValue_T("PTP", dptp), globaldefs.NameAndStringValue_T("CTP", dctp)]]

    additionalCreationInfo = []
    createData = SNCCreateData_T(userLabel, forceUniqueness, owner, direction, staticProtectionLevel, protectionEffort,
                                 rerouteAllowed, networkRouted, sncType, layerRate, ccInclusions, neTpInclusions,
                                 fullRoute, neTpSncExclusions, aEnd, zEnd, additionalCreationInfo)

    try:
        supported_mngrs = nmslogin.getManagers()
        # print(supported_mngrs)
        mlsn_mngr = supported_mngrs.get("MultiLayerSubnetwork")
        mlsn = MultiLayerSubnetwork()


        snc = mlsn.createAndActivateSNC(mlsn_mngr, createData, tolerableImpact=_0_subnetworkConnection.GOI_HITLESS, emsFreedomLevel=EMSFree,  return_corba_obj=1)

        print(snc)
        print(createData)
        return createData, corbaObjToDict(createData)
    except:
        print_exc()
    finally:
        nmslogin.endSession()


def delete_snc(sncname, neip):

    nmslogin.connect()
    try:
        supported_mngrs = nmslogin.getManagers()
        # print(supported_mngrs)
        mlsn_mngr = supported_mngrs.get("MultiLayerSubnetwork")
        mlsn = MultiLayerSubnetwork()
        subnetconn = make_managed_element_name({'EMS': emsname, "SubnetworkConnection": sncname, "MultiLayerSubnetwork": neip})
        print(subnetconn)
        snc = mlsn.deactivateAndDeleteSNC(mlsn_mngr, subnetconn, tolerableImpact=_0_subnetworkConnection.GOI_HITLESS, emsFreedomLevel=EMSFree, return_corba_obj=1)
        print(snc)
        return snc, corbaObjToDict(snc)
    except:
        print_exc()
    finally:
        nmslogin.endSession()




def set_user_label(subnetconn, newname):
    nmslogin.connect()
    try:
        supported_mngrs = nmslogin.getManagers()
        # print(supported_mngrs)
        com = supported_mngrs.get("MultiLayerSubnetwork")
        c = MultiLayerSubnetwork()
        snc = c.setUserLabel(com, subnetconn, newname)
        print(snc)
    except:
        print_exc()
    finally:
        nmslogin.endSession()


def modify_snc(userLabel, neip, sptp, sctp, dptp, dctp, rate):

    nmslogin.connect()
    forceUniqueness = False
    owner = "Tejas"
    direction = globaldefs.CD_BI
    staticProtectionLevel = _0_subnetworkConnection.UNPROTECTED
    protectionEffort = _0_subnetworkConnection.EFFORT_SAME
    rerouteAllowed = _0_subnetworkConnection.RR_NA
    networkRouted = _0_subnetworkConnection.NR_NA
    sncType = _0_subnetworkConnection.ST_SIMPLE
    layerRate = rate
    ccInclusions = []
    neTpInclusions = [[]]
    fullRoute = False
    neTpSncExclusions = [[]]

    aEnd = [(globaldefs.NameAndStringValue_T("EMS", emsname), globaldefs.NameAndStringValue_T("ManagedElement", neip), globaldefs.NameAndStringValue_T("PTP", sptp), globaldefs.NameAndStringValue_T("CTP", sctp))]
    zEnd = [[globaldefs.NameAndStringValue_T("EMS", emsname), globaldefs.NameAndStringValue_T("ManagedElement", neip), globaldefs.NameAndStringValue_T("PTP", dptp), globaldefs.NameAndStringValue_T("CTP", dctp)]]

    additionalCreationInfo = []
    createData = SNCCreateData_T(userLabel, forceUniqueness, owner, direction, staticProtectionLevel, protectionEffort,
                                 rerouteAllowed, networkRouted, sncType, layerRate, ccInclusions, neTpInclusions,
                                 fullRoute, neTpSncExclusions, aEnd, zEnd, additionalCreationInfo)

    try:
        supported_mngrs = nmslogin.getManagers()
        # print(supported_mngrs)
        mlsn_mngr = supported_mngrs.get("MultiLayerSubnetwork")
        mlsn = MultiLayerSubnetwork()

        delete_snc(userLabel, neip)
        time.sleep(1)
        snc = mlsn.createAndActivateSNC(mlsn_mngr, createData, tolerableImpact=_0_subnetworkConnection.GOI_HITLESS, emsFreedomLevel=EMSFree,  return_corba_obj=1)

        print(snc)
        print(createData)
        return createData, corbaObjToDict(createData)
    except:
        print_exc()
    finally:
        nmslogin.endSession()

if __name__ == '__main__':
    ne = "192.168.100.177"
    get_ems_info()
    # time.sleep(2)
    # get_all_ne()
    # time.sleep(2)
    # get_all_alarms()
    # time.sleep(2)
    # get_all_ne_alarms(ne)
    # time.sleep(2)
    # get_all_ne_equipment(ne)
    # time.sleep(2)
    # get_all_tls()
    # time.sleep(2)
    # create_snc("userLabel", "172.25.45.31", "/shelf=1/slot=9/port=2", "/eth=1", "/shelf=1/slot=9/port=514", "/oduflex=1-2-3-4-5-6-7-8-9-10", 10110)
    # create_snc("userLabel", ne, "/shelf=1/slot=10/port=2", "/eth=1", "/shelf=1/slot=10/port=504", "/oduflex=1-2-3-4-5-6-7-8-9-10", 10110)
    # time.sleep(2)
    # get_all_ne_SNC(ne)
    # time.sleep(2)
    # delete_snc("TMFCrossConnect-83", ne)
    # time.sleep(2)
    # get_all_ne_SNC(ne)
    # set_user_label()
    # modify_snc("TMFCrossConnect-5", ne, "/shelf=1/slot=2/port=2", "/eth=1", "/shelf=1/slot=2/port=514", "/oduflex=1-2-3-4-5-6-7-8-9-10", 10110)
