import datetime
import json
import os
import signal
import sys
import thread
import time

path = os.path.dirname(os.path.abspath(__file__))
sys.path.append(path + os.sep + "tmf" + os.sep + 'idlc_tmf_v35' + os.sep)
import CosNaming
import CosNotification

import CosNotifyComm__POA
import CosNotifyChannelAdmin
import emsSessionFactory
import nmsSession__POA
import notifications
import traceback
from omniORB import CORBA

# uncomment to enable SSL
from omniORB.sslTP import *
certificate_authority_file("/root/TMFpy/SSLKEY/tejems.pem")
key_file("/root/TMFpy/SSLKEY/tejems.pem")
key_file_password("iltwat")
###############################


### helper functions ####

def safe_int(a, defaultVal=0):
    try:
        return int(a)
    except:
        pass
    try:
        return int(float(a))
    except:
        return defaultVal



def print_traceback():
    exc_type, exc_value, exc_tb = sys.exc_info()
    print "\n####################################"
    print "########  ERROR TRACEBACK  #########\n"
    traceback.print_exception(exc_type, exc_value, exc_tb)
    print "\n####################################\n"



class triple_des:
    # Encrypt & Decrypt Constants
    ENCRYPT = 1
    DECRYPT = 0

    def __init__(self, key='19kbca=p11wdcmnbzk=0pdlt', alg='des_ede3_cbc', iv_key='\0' * 16, pad=None, padmode=None):
        self.key = key
        self.alg = alg
        self.iv_key = iv_key
        # Below lines Kept here for compatibility purpose
        self.pad = pad
        self.padmode = padmode

    def encrypt(self, plaintext):
        cryptor = self.get_cryptor(self.ENCRYPT)
        ret = cryptor.update(plaintext)
        ret = ret + cryptor.final()
        return ret

    def decrypt(self, ciphertext):
        cryptor = self.get_cryptor(self.DECRYPT)
        ret = cryptor.update(ciphertext)
        ret = ret + cryptor.final()
        return ret


def hexToInt(c):
    ret = ord(c) - ord('0')
    if ret > 9:
        ret = ord(c) - ord('A') + 10
    if ret > 15:
        ret = ord(c) - ord('a') + 10
    if ret < 0 or ret > 15:
        ret = 0
    return ret


def decryptConfig(value):
    try:
        if value == None or value == "":
            return value
        if not value:
            return ''
        if len(value) % 2 != 0:
            value = value + " "
        ciphertext = ""
        for i in range(0, len(value), 2):
            ciphertext = ciphertext + chr(hexToInt(value[i]) * 16 + hexToInt(value[i + 1]))
        ret = triple_des().decrypt(ciphertext)[8:]
        return ret
    except Exception, msg:
        print "\nMaxInputStats - decryptConfig - Exception, msg >> ", Exception, msg
        # logExceptionMsg(4,"Exception in decryptConfig %s"%msg)
        return ""


def isStandByActive(filename, chktime=180):
    try:
        hbtime = 0
        with open(filename, 'r') as f:
            hbtime = safe_int(f.readline())
            print "\nhbtime >> ", time.ctime(hbtime), (time.time() - hbtime), chktime
        if hbtime and (time.time() - hbtime) < chktime:  # standby process active
            return True
        return False
    except:
        pass
    return False


### helper function ends ######

# from redis_memory_standalone import REDIS_MEMCACHE

log_file_path = path + os.sep + "templates" + os.sep + 'tmf_notification.log'

if os.path.exists(log_file_path):
    os.remove(log_file_path)


def logMsg(level, msg, module='General'):
    msg = '%s:[%s] %s\n<br><br>' % (time.ctime(), module, str(msg))
    print msg
    with open(log_file_path, 'ab+') as log:
        log.write(msg)


FETCH_BULK = 100


### class for new
class NmsSession_I(nmsSession__POA.NmsSession_I):
    pass


exclude_probableCause_list = []
# print(exclude_probableCause_list)
##  PS_INDETERMINATE, 0
##  PS_CRITICAL, 1
##  PS_MAJOR, 2
##  PS_MINOR, 3
##  PS_WARNING, 4
##  PS_CLEARED 5
# perceivedSeverity = []

perceivedSeverity = [notifications.PS_INDETERMINATE,
                     notifications.PS_CRITICAL,
                     notifications.PS_MAJOR,
                     notifications.PS_MINOR,
                     notifications.PS_WARNING,
                     notifications.PS_CLEARED,
                     ]
exclude_perceivedSeverity_list = CORBA.Any(notifications._tc_PerceivedSeverityList_T, perceivedSeverity)



def listen_for_notification(listenerInst, channel):
    poa = listenerInst.orb.resolve_initial_references('RootPOA')
    poamgr = poa._get_the_POAManager()
    poamgr.activate()

    impl = StructuredPushConsumerImpl(listenerInst)
    pushConsumer = impl._this()

    consumer_admin, consID = channel.new_for_consumers(CosNotifyChannelAdmin.AND_OP)
    print "consumerID...", consID
    (proxy_supplier, proxy_id) = consumer_admin.obtain_notification_push_supplier(
        CosNotifyChannelAdmin.STRUCTURED_EVENT)
    print '\n\n proxy_supplier -- ', proxy_supplier
    print '\n\n proxy_id -- ', proxy_id
    struct_proxy_supplier = proxy_supplier._narrow(CosNotifyChannelAdmin.StructuredProxyPushSupplier)
    struct_proxy_supplier.connect_structured_push_consumer(pushConsumer)
    consumer_admin.subscription_change([CosNotification.EventType("*", "*")], [])
    print "\n ** Listening For Events ** \n"
    logMsg(4, "** Listening For Events **")
    listenerInst.orb.run()


class StructuredPushConsumerImpl(CosNotifyComm__POA.StructuredPushConsumer):
    def __init__(self, listenerInst):
        self.listenerInst = listenerInst
        self.orb = self.listenerInst.orb
        self.standby = listenerInst.standby
        global redismem
        global emsip
        global evedb
        global ha_heartbeat_path
        self.evedb = evedb
        self.emsip = emsip

        self.redis_key = 'TMF_NOTIFY_%s' % emsip
        self.redis_lkey = 'TMF_NOTIFY_LIST_%s' % emsip
        self.ha_heartbeat_path = ha_heartbeat_path


    def disconnect_structured_push_consumer(self):
        self.orb.shutdown(0)
        self.listenerInst.abnormalInterruption = True
        pass

    def offer_change(self, added, removed):
        pass

    def makesubdict(self, datas):
        # print "\ndatas >> ",datas
        name_dict = dict()
        try:
            for data in datas:
                name_dict[str(data.name)] = str(data.value)
        except Exception, msg:
            # print "\nException, msg >> ",Exception, msg
            return str(datas)
        return name_dict


    def push_structured_event(self, notification):
        # print "\n\nnotification = %s \n\n" % str(notification)
        # check tmf listener
        if self.standby:
            if not isStandByActive(self.ha_heartbeat_path):  # stand by mode. Dont execute further.
                print "In standby Mode - Ignoring Event"
                return

        notify_type = notification.header.fixed_header.event_type.type_name
        if notify_type == 'NT_HEARTBEAT':  # do nothing
            print "Tejas Corba Notifier - Heart beat received - %s" % time.ctime()

        logMsg(4, "Notification ->%s -->%s" % (notify_type, str(notification)))
        if notify_type == 'NT_ALARM':
            data = {'notify_time': time.time(), 'notify_type': notify_type,
                    'notify_domain': notification.header.fixed_header.event_type.domain_name}
            for n in notification.filterable_data:
                if type(n.value._v) == type(''):
                    data[n.name] = n.value._v
                else:
                    data[n.name] = self.makesubdict(n.value._v)
            print "\n******* EVENT **********\n", json.dumps(data, indent=4)

        else:
            data = {'notify_time': time.time(), 'notify_type': notify_type,
                    'notify_domain': notification.header.fixed_header.event_type.domain_name}
            for n in notification.filterable_data:
                if type(n.value._v) == type(''):
                    data[n.name] = n.value._v
                else:
                    data[n.name] = self.makesubdict(n.value._v)
            # print "\nnotify_type >> %s ---- %s " % (notify_type, str(notification))
            print json.dumps(data, indent=2)


class Listener:
    def __init__(self, corba_ip, corba_port, ems_name, user, pwd, vendor, tmf_class, tmf_version, alarm_event_filter,
                 clear_event_filter, standby=0):
        self.stop = False
        self.standby = standby
        dt = datetime.datetime.now()
        if not dt.second % 10:
            self.db_queue_key = time.mktime(dt.timetuple())
        else:
            self.db_queue_key = time.mktime(dt.timetuple()) - (dt.second % 10)
        thread.start_new_thread(self.db_key_creator, ())
        try:
            #For SSL 
            argv = ["-ORBInitRef", "NameService=corbaloc:ssliop:1.2@%s:%s/NameService" % (corba_ip, corba_port), "-ORBtraceLevel", '25', "-ORBsslVerifyMode", "none", "-ORBendPoint", "giop:ssl::"]
            #For non SSL
            #argv = ["-ORBInitRef", "NameService=corbaloc:iiop:%s:%s/NameService" % (corba_ip, corba_port), "-ORBtraceLevel", '25']
            self.orb = CORBA.ORB_init(argv, CORBA.ORB_ID)
            
            self.abnormalInterruption = False
        except:
            print "Exception in creating session"
            print_traceback()
            self.abnormalInterruption = True

    def run(self):
        
        initialContext = self.orb.resolve_initial_references("NameService")
        name = [CosNaming.NameComponent("NotifyEventChannelFactory","")]
        rc = initialContext._narrow(CosNaming.NamingContext)
        echannel_ref = rc.resolve(name)
        print dir(echannel_ref)
        channelFactory = echannel_ref._narrow(CosNotifyChannelAdmin.EventChannelFactory)
        print dir(channelFactory)
        channel = channelFactory.get_event_channel(1)
        print '\n\n channel... ', dir(channel), '\n', dir(channel._obj)
        logMsg(4, "** Initialize Event Listening **")
        listen_for_notification(self, channel)

    def disconnect(self, stopThread=False):
        print "** Disconnecting ORB & Stop All Threads - %s **" % str(stopThread)
        try:
            self.orb.shutdown(0)
            print "** ORB Disconnected **"
        except:
            print "** ORB Disconnected[0] **"
        self.stop = stopThread

    def db_key_creator(self):
        while True:
            dt = datetime.datetime.now()
            if dt.second % 10 == 0:
                self.db_queue_key = time.mktime(dt.timetuple())
            time.sleep(1)


def main(corba_ip, corba_port, ems_name, user, pwd, vendor, tmf_class, tmf_version, alarm_event_filter,
         clear_event_filter, standby=0):
    global appPointer
    global redismem
    global emsip
    global evedb
    global ha_heartbeat_path
    listener_path = os.path.abspath(__file__)
    ha_heartbeat_path = listener_path.split(os.sep + 'tmf')[0] + os.sep + 'ha_chk.dat'

    inst = Listener(corba_ip, corba_port, ems_name, user, pwd, vendor, tmf_class, tmf_version, alarm_event_filter,
                    clear_event_filter, standby=standby)

    emsip = corba_ip
    try:
        appPointer = inst
        if not inst.abnormalInterruption:
            thread_identifier = thread.start_new_thread(inst.run, ())
        while not inst.stop:
            time.sleep(1)
            if inst.abnormalInterruption:
                # re - initialize
                print "\n*****Re-Initializing Listener for IP - %s*****\n" % corba_ip
                del inst
                inst = Listener(corba_ip, corba_port, ems_name, user, pwd, vendor, tmf_class, tmf_version,
                                alarm_event_filter, clear_event_filter)
                appPointer = inst
                if not inst.abnormalInterruption:
                    thread_identifier = thread.start_new_thread(inst.run, ())
                time.sleep(2)

        print "** Waiting for 5 seconds ** "
        time.sleep(5)
        print "** Safe Exit **"
    except Exception, msg:
        print "\nException, msg >> ", Exception, msg
    except:
        print(4, 'Stopping Main Thread due to Exception', modulename)
    os._exit(1)


def shutdown():
    # Stop the services and other threads
    global appPointer
    appPointer.disconnect(True)
   


modulename = "TMF Notify Listener"
appPointer = None
redismem = None
emsip = None
evedb = None
ha_heartbeat_path = None

if __name__ == '__main__':
    corba_ip = "192.168.228.104"
    corba_port = "20900"
    ems_name = "EMS_1"
    user = "administrator"
    pwd = "tejas;Allowed"
    vendor = "TejasNetworks"
    tmf_class = "TMF_MTNM"
    tmf_version = "3.5"
    alarm_event_filter = "*"
    clear_event_filter = "*"
    standby = 0
    print "\nstandby >> ", standby
    logfile = "tmf_%s_log" % corba_ip
    print "\nConnection String -> %s|%s|%s|%s|%s|%s|%s|%s\n" % (
    corba_ip, corba_port, ems_name, user, pwd, vendor, tmf_class, tmf_version)
    try:
        f = open('tmf_%s.pid' % corba_ip, 'wb')
        f.write(str(os.getpid()))
        f.close()
    except:
        print "Exception in writing process id to a file"


    def shutdownSignal(*args):
        print "\n** Shutting Down ** "
        shutdown()


    try:
        signal.signal(signal.SIGINT, shutdownSignal)
        main(corba_ip, corba_port, ems_name, user, pwd, vendor, tmf_class, tmf_version, alarm_event_filter,
             clear_event_filter, standby)
    except KeyboardInterrupt:
        print "Stopping Corba Notifier Listener !!!"
    shutdown()
    os._exit(1)
